"""Instant Now/Next guide data for the on-video channel list and Kodi widgets.

This module only reads existing normalized EPG cache: remote button presses and
skin-widget refreshes must never wait for an external Xtream server.
"""
import time


def _as_int(value):
    try:
        return int(float(value))
    except (TypeError, ValueError, OverflowError):
        return 0


def _find_events(data, ids):
    for ident in ids:
        if ident and isinstance(data.get(str(ident)), list):
            return data[str(ident)]
    return []


def guide_for_channel(cache, epg_id='', stream_id='', now=None):
    """Return now/next dict; empty strings mean the provider has no EPG data."""
    result = {'now': '', 'next': '', 'description': '', 'image': '',
              'now_time': '', 'next_time': ''}
    if not isinstance(cache, dict):
        return result
    ts = int(time.time() if now is None else now)
    # A manually mapped Xtream stream ID must override the provider's guide ID.
    events = _find_events(cache, (stream_id, epg_id))
    valid = []
    for e in events:
        if not isinstance(e, dict):
            continue
        start = _as_int(e.get('start_timestamp') or e.get('start'))
        end = _as_int(e.get('stop_timestamp') or e.get('end_timestamp') or e.get('stop'))
        title = str(e.get('name') or e.get('title') or '').strip()
        if start and end > start and title:
            valid.append((start, end, title, e))
    valid.sort(key=lambda x: x[0])
    current = next((item for item in valid if item[0] <= ts < item[1]), None)
    future = next((item for item in valid if item[0] > ts), None)
    if current:
        result['now'] = current[2]
        result['now_time'] = time.strftime('%H:%M', time.localtime(current[0]))
        result['description'] = str(current[3].get('descr') or current[3].get('description') or '')
        result['image'] = str(current[3].get('screenshot_uri') or '')
        # Following programme must begin after the current programme.
        future = next((item for item in valid if item[0] >= current[1]), future)
    if future:
        result['next'] = future[2]
        result['next_time'] = time.strftime('%H:%M', time.localtime(future[0]))
    return result


def programme_plot(info):
    parts = []
    if info.get('now'):
        parts.append('Jetzt {}: {}'.format(info.get('now_time', ''), info['now']).strip())
    if info.get('next'):
        parts.append('Danach {}: {}'.format(info.get('next_time', ''), info['next']).strip())
    if info.get('description'):
        parts.append(str(info['description']))
    return '\n'.join(parts) if parts else 'Zurzeit keine EPG-Daten vorhanden.'


def row_title(name, info):
    title = str(name)
    if info.get('now'):
        title += '  |  Jetzt: ' + str(info['now'])
    if info.get('next'):
        title += '  |  Danach: ' + str(info['next'])
    return title

# Bounded asynchronous Xtream short-guide fallback for missing XMLTV data.
_SHORT_LOCK = None
_SHORT_INFLIGHT = set()
_SHORT_SEEN = {}
_SHORT_FAILED = {}

def _short_guide(raw, now=None):
    """Normalize cached get_short_epg events into XMLTV-compatible Now/Next."""
    import base64
    ts = int(time.time() if now is None else now)
    entries = raw.get('epg_listings', []) if isinstance(raw, dict) else []
    normalized = []
    for item in entries:
        if not isinstance(item, dict):
            continue
        title = str(item.get('title') or '').strip()
        try:
            decoded = base64.b64decode(title, validate=True).decode('utf-8')
            if decoded.strip():
                title = decoded
        except (ValueError, TypeError, UnicodeError):
            pass
        start = _as_int(item.get('start_timestamp'))
        stop = _as_int(item.get('stop_timestamp') or item.get('end_timestamp'))
        if start and stop > start and title:
            normalized.append({'name': title, 'start_timestamp': start,
                               'stop_timestamp': stop})
    return guide_for_channel({'_short': normalized}, '_short', now=ts)

def cached_short_guide(client, stream_id, now=None):
    if not stream_id:
        return guide_for_channel({}, now=now)
    data = client._get_json('get_short_epg',
        extra={'stream_id': str(stream_id), 'limit': 4}, cached_only=True)
    return _short_guide(data, now=now)

def _view_key(path):
    import hashlib,json,urllib.parse
    p=urllib.parse.urlsplit(path)
    q=dict(urllib.parse.parse_qsl(p.query))
    if p.scheme!='plugin' or p.netloc!='plugin.video.xtreammate' or q.get('action')!='live_channels':
        return ''
    data=[q.get('pid',''),q.get('group',''),q.get('page','0')]
    return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()


def prefetch_short_guides(portal, channels, limit=24, view_path=''):
    """Send a bounded page request to the long-lived service, not a GUI thread."""
    import json,uuid,xbmcgui
    if not isinstance(portal,dict) or portal.get('type')!='xtream': return
    sids=[str(ch.extra.get('stream_id')) for ch in channels if ch.extra.get('stream_id')][:limit]
    if not sids: return
    request={'pid':str(portal['id']),'sids':sids,'at':time.time(),
             'nonce':uuid.uuid4().hex,'view':_view_key(view_path)}
    xbmcgui.Window(10000).setProperty('XtreamMate.ShortGuideRequest',json.dumps(request))


def refresh_visible_page(portal_id, view_key=''):
    """Refresh only our current sender page, never a player or another add-on."""
    import xbmc,urllib.parse
    try:
        path=xbmc.getInfoLabel('Container.FolderPath')
        key=_view_key(path)
        params=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(path).query))
        if not key or params.get('pid')!=str(portal_id): return
        if view_key and key!=view_key: return
        if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'): return
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


_LAST_REQUEST=''


def poll_short_guides():
    import json,xbmcgui
    import portals
    global _LAST_REQUEST
    window=xbmcgui.Window(10000)
    raw=window.getProperty('XtreamMate.ShortGuideRequest')
    if not raw or len(raw)>8192: return
    try: request=json.loads(raw)
    except (ValueError,TypeError): return
    if not isinstance(request,dict) or request.get('nonce')==_LAST_REQUEST: return
    try:
        if not 0<=time.time()-float(request.get('at',0))<120: return
    except (ValueError,TypeError): return
    portal=portals.get_by_id(request.get('pid'))
    if not portal or not portal.get('enabled',True) or portal.get('type')!='xtream': return
    sids=request.get('sids')
    if not isinstance(sids,list): return
    sids=[sid for sid in sids[:24] if isinstance(sid,str) and sid.isdecimal()]
    if _start_short_guides(portal,sids,str(request.get('view') or '')):
        _LAST_REQUEST=request['nonce']


def _start_short_guides(portal, sids, view_key=''):
    """Prefetch missing visible TV programmes without waiting in Kodi navigation."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from xtream import XtreamClient
    global _SHORT_LOCK
    if _SHORT_LOCK is None:
        _SHORT_LOCK = threading.Lock()
    if not isinstance(portal, dict) or portal.get('type') != 'xtream':
        return
    pid = str(portal['id'])
    current = time.time()
    with _SHORT_LOCK:
        if _SHORT_INFLIGHT:
            return False
        ids = [sid for sid in sids if current-_SHORT_SEEN.get((pid,sid),0)>1800
               and current-_SHORT_FAILED.get((pid,sid),0)>30]
        if not ids:
            return True
        _SHORT_INFLIGHT.add(pid)
    def worker():
        try:
            changed=[]
            xc = XtreamClient(portal['xc_host'],portal['xc_user'],portal['xc_pass'])
            def fetch(sid):
                cached=cached_short_guide(xc,sid)
                if cached['now'] or cached['next']:
                    _SHORT_SEEN[(pid,sid)]=time.time()
                    return
                try:
                    data=xc.get_short_epg(sid,limit=4,force_refresh=True)
                    guide=_short_guide(data)
                    if guide['now'] or guide['next']:
                        _SHORT_SEEN[(pid,sid)]=time.time()
                        changed.append(sid)
                    else:
                        _SHORT_FAILED[(pid,sid)]=time.time()
                except Exception:
                    _SHORT_FAILED[(pid,sid)]=time.time()
            with ThreadPoolExecutor(max_workers=3) as executor:
                list(executor.map(fetch,ids))
            for history in (_SHORT_SEEN,_SHORT_FAILED):
                if len(history)>512:
                    for key in sorted(history,key=history.get)[:-512]:
                        history.pop(key,None)
            if view_key and changed:
                # Never refresh an unrelated directory or steal fullscreen
                # focus when the user has left the requested sender page.
                refresh_visible_page(pid,view_key)
        finally:
            with _SHORT_LOCK:
                _SHORT_INFLIGHT.discard(pid)
    try:
        threading.Thread(target=worker,daemon=True,name='XCMateShortGuide').start()
    except RuntimeError:
        with _SHORT_LOCK: _SHORT_INFLIGHT.discard(pid)
        return False
    return True
