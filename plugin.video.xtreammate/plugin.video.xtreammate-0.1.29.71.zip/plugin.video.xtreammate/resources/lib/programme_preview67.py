"""Single coalescing local-cache reader; no GUI SQL/files/HTTP."""
import os,threading,time,uuid
_lock=threading.Lock();_wanted={};_done={};_wake=threading.Event();_thread=None
def eligible(art):
 from programme_image69 import eligible as admit69
 return admit69(art)
def _work():
 import xbmc
 monitor=xbmc.Monitor()
 if not all(callable(getattr(monitor,name,None)) for name in ('abortRequested','waitForAbort')):return
 while not monitor.abortRequested():
  _wake.wait(.5);_wake.clear()
  with _lock:jobs=list(_wanted.items());_wanted.clear()
  for token,(key,portal,channel,event) in jobs:
   if monitor.waitForAbort(.001):return
   try:
    from programme_events46 import describe
    from programme_art46 import cached
    complete69=event.get('pid')==str(portal['id']) and event.get('sid')==str(channel.get('sid',channel.get('stream_id',''))) and event.get('code') in ('LOCAL_EVENT','CACHED_EVENT') and event.get('key')
    value=dict(event) if complete69 else describe(portal,channel,event,event.get('canonical46',event.get('canonical','')),event.get('revision68',event.get('revision')))
    art=cached(value)
    from programme_requests68 import request,result
    if not eligible(art) and not event.get('_no_art_request68'):request(value,priority=True)
    art=result(value,art)
    art=dict(art) if eligible(art) else {}
   except Exception:art={}
   with _lock:
    if token in _done and _done[token][0]==key:_done[token]=(key,art)
class Preview:
 def __init__(self,owner,rect):
  import xbmcgui,xbmcaddon,xbmc
  self.controls=();self.available=callable(getattr(owner,'addControls',None)) and all(callable(getattr(xbmc.Monitor(),name,None)) for name in ('abortRequested','waitForAbort'))
  self.token=uuid.uuid4().hex;self._next=0;self._key=None;self._painted67=None;self._hidden67=False;self._source_hidden67=False
  if not self.available:return
  x,y,w,h=rect;root=xbmcaddon.Addon().getAddonInfo('path')
  self.image=xbmcgui.ControlImage(x,y,w,h,'',aspectRatio=2)
  self.logo=xbmcgui.ControlImage(x+w-46,y+h-24,42,20,os.path.join(root,'resources/media/tmdb60/tmdb.png'),aspectRatio=2)
  self.source=xbmcgui.ControlLabel(x,y+h+2,w,22,'','font12','0xFFBEC4CD')
  self.controls=(self.image,self.logo,self.source);owner.addControls(list(self.controls));self.hide()
 def hide(self):
  if not self._hidden67:
   for control in self.controls:control.setVisible(False)
  self._hidden67=True;self._painted67=None;self._source_hidden67=True
  with _lock:_wanted.pop(self.token,None);_done.pop(self.token,None)
  self._key=None
 def hide_source(self):
  if self.available and not self._source_hidden67:self.source.setVisible(False);self._source_hidden67=True
 def render(self,portal,channel,event):
  global _thread
  if not self.available or not portal or not event or not channel:self.hide();return
  from programme_events46 import key
  row=dict(channel.extra,sid=str(channel.extra.get('stream_id','')),name=channel.name) if hasattr(channel,'extra') else dict(channel)
  identity=key(portal['id'],row.get('sid',row.get('stream_id','')),event)
  if self._key!=identity:self.hide();self._key=identity
  now=time.monotonic()
  with _lock:
   if now>=self._next:
    self._next=now+.5;_done.setdefault(self.token,(identity,{}));_wanted[self.token]=(identity,dict(portal),row,dict(event))
    while len(_wanted)>2:_wanted.pop(next(iter(_wanted)))
    if _thread is None or not _thread.is_alive():_thread=threading.Thread(target=_work,name='XCMate-local-preview67',daemon=True);_thread.start()
    _wake.set()
   current=_done.get(self.token,(None,{}));art=current[1] if current[0]==identity else {}
  real=eligible(art)
  signature67=(real,art.get('image') if real else '',art.get('source') if real else '',art.get('image_scope57') if real else '')
  if signature67==self._painted67:return
  self._painted67=signature67;self._hidden67=not real;self._source_hidden67=not real
  if real:self.image.setImage(art['image'])
  self.image.setVisible(real);self.logo.setVisible(real and str(art.get('source','')).startswith('tmdb'))
  self.source.setLabel(('TMDB' if str(art.get('source','')).startswith('tmdb') else 'TVmaze' if str(art.get('source','')).startswith('tvmaze') else 'XMLTV' if art.get('source')=='xmltv_event' else 'Provider')+(' · Serienbild' if art.get('image_scope57')=='series_fallback' else '') if real else '')
  self.source.setVisible(real)
