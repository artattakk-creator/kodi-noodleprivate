"""Single owner-pumped source manager and readable report on existing APIs."""
import time
from concurrent.futures import ThreadPoolExecutor
import xbmcgui
from menu_icons45 import select
from owner_dispatch import OwnerDispatch,native_init


class Manager53(OwnerDispatch,xbmcgui.WindowXMLDialog):
    _native_surface='dialog'
    def configure(self,portal):
        self._configure_owner();self.portal=portal;self._pool=ThreadPoolExecutor(max_workers=1)
        self._generation=0;self._closed=False;self.rows=[];self.mode='sources';self._last=0;self.scroll=0;self.next_action=None
    @native_init
    def onInit(self):
        self.getControl(101).setLabel('XCMate · EPG-Manager')
        for cid,label in [(401,'Quellen hinzufügen'),(402,'Jetzt aktualisieren'),(403,'Aktualisierungsbericht anzeigen'),(404,'Quellenliste'),(405,'Großes EPG / Senderzuordnung'),(406,'Zurück'),(407,'Automatisches Intervall'),(408,'Bericht nach oben'),(409,'Bericht nach unten')]:self.getControl(cid).setLabel(label)
        self._load();self.setFocusId(410 if self.portal.get('type')=='xtream' else 401)
    def _load(self):
        from epg_report53 import overview
        self.mode='sources';self.getControl(300).setVisible(False);self.getControl(200).setVisible(True)
        self.getControl(102).setLabel('Gespeicherte Quellen werden gelesen …')
        def load():
            from wizard_epg54 import pending
            from portals import get_by_id
            portal=get_by_id(self.portal['id']) or self.portal
            return portal,overview(portal),pending(portal)
        def ready(value):
            self.portal,rows,self._setup_pending54=value;self._loaded(rows)
        self._request(load,ready)
    def _loaded(self,rows):
        from epg_report53 import meaning
        self.getControl(410).setLabel('Anbieter-EPG deaktivieren' if self.portal.get('provider_epg_enabled',True) else 'Anbieter-EPG aktivieren')
        self.getControl(410).setEnabled(self.portal.get('type')=='xtream')
        self.rows=rows;control=self.getControl(200);pos=control.getSelectedPosition();control.reset()
        items=[]
        for row in rows:
            saved=row['saved'];counts=(str(saved.get('channels',0))+' Sender · '+str(saved.get('programmes',0))+' Sendungen') if row['statistics_code']=='READY' else 'Bestand derzeit nicht sicher lesbar'
            items.append(xbmcgui.ListItem(('✓ ' if row['enabled'] else '○ ')+str(row['rank'])+' · '+row['name'],label2=meaning(row['code'])+' · '+counts))
        control.addItems(items)
        if items:control.selectItem(min(pos,len(items)-1))
        from epg_schedule53 import interval
        self.getControl(102).setLabel('Automatisch alle '+str(min(interval(),86400)//3600)+' Stunden · OK: Quelle verwalten · Einzelzuordnung im großen EPG · Menü: Senderabdeckung')
        self.getControl(402).setLabel('Jetzt aktualisieren')
        self.getControl(411).setEnabled(bool(getattr(self,'_setup_pending54',False)))
        self._detail()
    def _detail(self):
        if self.mode!='sources' or not self.rows:return
        row=self.rows[min(self.getControl(200).getSelectedPosition(),len(self.rows)-1)]
        from epg_report53 import stamp
        saved=row['saved']
        progress=row.get('progress59',{})
        details=('Download/Import: '+str(progress.get('bytes',0))+' Bytes · '+str(progress.get('programmes',0))+' gelesen · '+str(progress.get('count',0))+' zugeordnet\n') if row.get('code') in ('RUNNING','DOWNLOADING','PARSING','SAVING','VERIFIED') else ''
        if progress.get('http_status'):details+='HTTP-Status: '+str(progress['http_status'])+'\n'
        self.getControl(103).setText(details+'Letzter Versuch: '+stamp(row.get('last_attempt66'))+'\n'+'Letzter Erfolg: '+stamp(row['last_success'])+'\nLetzter protokollierter Fehler: '+stamp(row['last_failure'])+'\nGespeicherter Zeitraum: '+stamp(saved.get('first'))+' bis '+stamp(saved.get('last')))
    def onFocus(self,cid):
        if cid==200:self._detail()
    def _query_failed(self,exc):self.getControl(102).setLabel('EPG-Zugriff oder Speichern nicht bestätigt. Daten bleiben erhalten.')
    def _reports(self):
        from epg_report53 import history
        def ready(runs):
            if not runs:self.getControl(102).setLabel('Noch kein abgeschlossener Aktualisierungsbericht vorhanden.');return
            from epg_report53 import stamp,meaning,describe
            choice=select(xbmcgui.Dialog(),'Aktualisierungsbericht anzeigen',[stamp(r.get('started'))+' · '+meaning(r.get('code')) for r in reversed(runs)])
            if not 0<=choice<len(runs):return
            self.mode='report';self.scroll=0;self.getControl(200).setVisible(False);self.getControl(103).setText('')
            self.getControl(300).setVisible(True);self.getControl(300).setText(describe(runs[-1-choice],self.portal));self.getControl(300).scroll(0)
            self.getControl(102).setLabel('Bericht mit „nach oben / nach unten“ lesen · Zurück führt zur Quellenliste.')
            self.setFocusId(409)
        self._request(lambda:history(self.portal['id']),ready)
    def onClick(self,cid):
        if cid==406:
            if self.mode=='report':self._load();self.setFocusId(404)
            else:self.close()
            return
        if self._pending_future:return
        import epg_sources as sources
        if cid==410:
            self._toggle_provider58()
        elif cid==401:
            choice=select(xbmcgui.Dialog(),'EPG-Quelle hinzufügen',['Deutschland / Österreich / Schweiz','XMLTV-Adresse','XMLTV-Datei','Zurück'])
            if choice==0:sources._choose_preset(self.portal)
            elif choice in (1,2):
                uri=xbmcgui.Dialog().input('XMLTV-Adresse (HTTP/HTTPS)') if choice==1 else xbmcgui.Dialog().browse(1,'XMLTV-Datei auswählen','files','.xml|.gz|.xml.gz',False,False,'')
                if uri:
                    name=xbmcgui.Dialog().input('Name dieser EPG-Quelle',defaultt='XMLTV')
                    try:
                        from provider_epg58 import add_source
                        add_source(self.portal,name,uri,local=choice==2)
                    except (OSError,ValueError) as exc:xbmcgui.Dialog().ok('XCMate EPG','Diese Adresse ist bereits der Anbieter-EPG. Anbieter-EPG aktivieren und Jetzt aktualisieren wählen.' if str(exc)=='DUPLICATE_PROVIDER_FEED' else 'Quelle nicht hinzugefügt. Adresse, Dateityp und Schreibrechte prüfen.')
            self._load()
        elif cid==411 and getattr(self,'_setup_pending54',False):
            self.next_action='resume_epg54';self.close();return
        elif cid==402:
            from portals import get_by_id
            self.portal=get_by_id(self.portal['id']) or self.portal
            from epg import request_refresh
            ok=request_refresh(self.portal['id'],self.portal,force=True)
            if ok:self._refresh_until58=time.monotonic()+600;self._next_status58=time.monotonic()+2
            self.getControl(102).setLabel('Aktualisierung angefordert; Speicherung noch nicht bestätigt.' if ok else 'Aktualisierung blockiert. Bestehende EPG-Sicherung und laufende Importe prüfen.')
        elif cid==403:self._reports()
        elif cid==404:self._load()
        elif cid==405:self.next_action='guide';self.close()
        elif cid==407:
            values=[24,6,12];choice=select(xbmcgui.Dialog(),'Automatischer EPG-Download',[str(h)+' Stunden' for h in values])
            if 0<=choice<len(values):
                import xbmcaddon
                xbmcaddon.Addon().setSetting('epg_refresh_hours',str(values[choice]))
            self._load()
        elif cid in (408,409) and self.mode=='report':
            self.scroll=max(0,self.scroll+(-12 if cid==408 else 12));self.getControl(300).scroll(self.scroll)
        elif cid==200 and self.rows:
            row=self.rows[self.getControl(200).getSelectedPosition()]
            if row['id']=='provider':
                if xbmcgui.Dialog().yesno('Anbieter-EPG','Anbieter-EPG '+('deaktivieren?' if row['enabled'] else 'aktivieren?')):
                    self._toggle_provider58()
                return
            else:sources._manage_source(self.portal,row['record'])
            self._load()
    def pump(self):
        super().pump()
        now=time.monotonic()
        if not self._closed and self.mode=='sources' and not self._pending_future and now<getattr(self,'_refresh_until58',0) and now>=getattr(self,'_next_status58',0):
            self._next_status58=now+2;self._load()
    def _coverage66(self):
        from epg_coverage66 import report
        from stream_epg import active_streams
        from itertools import islice
        def ready(rows):
            from epg_report53 import stamp
            self.mode='report';self.scroll=0;self.getControl(200).setVisible(False);self.getControl(103).setText('');self.getControl(300).setVisible(True)
            meanings={'READY':'Jetzt/Danach lokal bereit','UNMAPPED':'Keine eindeutige Zuordnung','SOURCE_EMPTY':'Keine gespeicherten Quellereignisse','EVENT_OUT_OF_WINDOW':'Lücke oder Ereignis außerhalb der aktuellen Zeit','STALE':'Gespeicherte Abdeckung abgelaufen','DB_UNAVAILABLE':'Datenbank momentan nicht lesbar'}
            lines=['Lokale Senderabdeckung · kein Netzabruf']
            for row in rows:lines.extend(['',row.get('name') or 'Sender '+row['sid'],meanings.get(row['code'],row['code']),stamp(row.get('first'))+' bis '+stamp(row.get('last'))])
            self.getControl(300).setText('\n'.join(lines));self.getControl(300).scroll(0);self.getControl(102).setLabel('Lokale Prüfung der ersten bis zu 512 aktivierten Sender · Zurück: Quellenliste');self.setFocusId(409)
        self._request(lambda:report(self.portal,list(islice(active_streams(self.portal),512))),ready)

    def _toggle_provider58(self):
        from provider_epg58 import toggle
        def ready(portal):
            self.portal=portal
            self._load()
            self.getControl(410).setLabel('Anbieter-EPG deaktivieren' if portal.get('provider_epg_enabled',True) else 'Anbieter-EPG aktivieren')
            self.getControl(102).setLabel('Einstellung gespeichert. Aktiviert ist noch kein erfolgreicher Import. Jetzt aktualisieren wählen.' if portal.get('provider_epg_enabled',True) else 'Anbieter-EPG deaktiviert. Externe Quellen und gespeicherte Daten bleiben erhalten.')
        self._request(lambda:toggle(self.portal),ready)
    def onAction(self,action):
        if action.getId() in (9,10,92):self.onClick(406)
        elif action.getId()==117 and self.mode=='sources' and not self._pending_future:self._coverage66()
        elif action.getId() in (3,4) and self.mode=='sources':self._detail()
    def close(self):
        self._gui()
        if self._closed:return
        self._closed=True;self._generation+=1
        if self._pending_future:self._pending_future.cancel()
        self._pending_future=self._pending_apply=None;self._pool.shutdown(wait=False,cancel_futures=True);super().close()


def manage(portal):
    import xbmcaddon
    w=Manager53('XCMateEPGManager53.xml',xbmcaddon.Addon().getAddonInfo('path'),'Default','720p');w.configure(portal);w.run()
    return w.next_action
