"""Session-scoped explicit TV exit; callbacks request, service stops/returns."""
import hashlib,json,time
from urllib.parse import urlencode
import xbmc,xbmcgui
KEY='XCMate.LiveExit'
SESSION='XtreamMate.LiveSession'


def _marker():return xbmcgui.Window(10000)


def state():
    try:
        value=json.loads(_marker().getProperty(KEY))
        from playback_exit import _session
        if isinstance(value,dict) and _session(json.dumps(value.get('session'))) and value.get('phase') in ('requested','stopping','home','complete','failed','return_pending78') and 0<=time.time()-value['at']<86400:return value
    except (ValueError,TypeError,KeyError):pass
    return None


def _save(value):_marker().setProperty(KEY,json.dumps(value))


def _trace(stage,session=None):
    # Stable correlation without clear portal, sender, nonce or URL in the log.
    digest=hashlib.sha256(json.dumps(['live',(session or {}).get('nonce')]).encode()).hexdigest()[:12]
    try:
        xbmc.log('[XCMate][LIVE_EXIT] stage='+stage+' session='+digest+
                 ' window='+str(int(xbmcgui.getCurrentWindowId())),xbmc.LOGINFO)
    except (AttributeError,RuntimeError):pass


def new_selection():
    # Called by an actual resolver/tune announcement; service URL-recovery is
    # suppressed while this intent exists and cannot create this selection.
    _marker().clearProperty(KEY)


def request(navigator,reason='USER_BACK'):
    if getattr(navigator,'_exiting',False):return True
    from playback_exit import identity,_same
    player=xbmc.Player();token=identity(player)
    if token is None and not player.isPlayingVideo():token=getattr(navigator,'_owned_token',None)
    if not token or token[0]!='live' or token[1]['pid']!=str(navigator.portal['id']):return False
    from live_overlay import session_from_property
    announced=session_from_property(_marker().getProperty(SESSION))
    pending=None
    if announced and not _same(token,('live',announced)):
        previous=getattr(navigator,'_previous_session',None)
        if not (previous and _same(token,('live',previous)) and announced['pid']==str(navigator.portal['id']) and announced['sid']==navigator.sid):return False
        pending={k:announced[k] for k in ('pid','sid','nonce','at')}
    prior=state()
    if prior and _same(('live',prior['session']),token):
        # The latch belongs to the session, not one Python WindowDialog. A
        # reconstructed/reentrant navigator cannot replay Stop/Home or reset
        # an already committed phase/deadline.
        navigator._exiting=True;navigator._exit_nonce=token[1]['nonce']
        return True
    value=dict(session={k:token[1][k] for k in ('pid','sid','nonce','at')},phase='requested',at=time.time(),deadline=time.monotonic()+5,not_before=time.monotonic()+.15)
    if token[1].get('origin_window48')==10000:value['origin_window48']=10000
    value['pending']=pending;value['reason']=reason if reason in ('USER_BACK','USER_STOP','USER_HOME') else 'USER_BACK'
    _save(value);navigator._exiting=True;navigator._exit_nonce=token[1]['nonce']
    _marker().setProperty('XCMate.PrePlay.Cancel',(pending or token[1])['nonce'])
    _trace('STOP_REQUESTED',token[1]);return True


def _poll(navigator=None):
    value=state()
    if value is None:
        # A consciously selected new session replaces the old exiting dialog.
        if navigator is not None and getattr(navigator,'_exiting',False):navigator.close()
        return False
    session=value['session'];marker=_marker()
    from live_overlay import session_from_property
    current=session_from_property(marker.getProperty(SESSION))
    allowed=[session]+([value['pending']] if value.get('pending') else [])
    if current and not any(current['nonce']==item['nonce'] for item in allowed):
        if navigator is not None and getattr(navigator,'_exiting',False):navigator.close()
        marker.clearProperty(KEY);return False
    from exit_jobs import blocked
    if blocked():return True
    from exit_jobs import state as job_state
    job=job_state()
    from live_trace48 import observe as observe_return48
    observe_return48(value,job)
    late78=bool(job and job.get('late_ack78') and job.get('phase')=='complete' and job['token'][1]['nonce']==session['nonce'] and not value.get('recovery46'))
    if late78:
        # The native Stop is complete. Its GUI return is a separate guarded
        # stage, never a false STOP_TIMEOUT and never another Stop request.
        if value['phase'] not in ('return_pending78','complete'):
            value['phase']='return_pending78';_save(value);_trace('STOP_ACK_RETURN_PENDING',session);return True
        if value['phase']=='return_pending78':
            from live_recovery46 import resume
            resume(value,job);return True
    if job and job['phase'] in ('failed','timeout') and job['token'][1]['nonce']==session['nonce']:
        from live_recovery46 import resume
        if resume(value,job):return True
        if value.get('recovery46')=='LATE_ACK_VERIFIED':
            pass  # Continue the existing Stop-done/Home path, never repost Stop.
        else:
            if value['phase']!='failed':
                value['phase']='failed';_save(value);_trace('STOP_TIMEOUT' if job['phase']=='timeout' else 'STOP_REJECTED',session)
                if navigator is not None and not navigator._closed:navigator.close()
            return True  # Native timeout remains a recorded failure.
    player=xbmc.Player()
    from playback_exit import identity,_same
    from exit_jobs import request as stop_owned
    if value['phase'] in ('complete','failed'):
        # A past live Exit must not disable media_progress/playback_exit for
        # a later movie or a foreign add-on. Keep the root-autoplay tombstone.
        return not player.isPlayingVideo() or any(_same(identity(player),('live',item)) for item in allowed)
    token=identity(player)
    from live_return59 import stop_confirmed
    confirmed59=stop_confirmed(value,job)
    playing=player.isPlaying() if hasattr(player,'isPlaying') else player.isPlayingVideo()
    if playing and token is None and value['phase']=='stopping' and job and job.get('worker_done') and job.get('result')=='complete' and job['token'][1]['nonce']==session['nonce']:
        # Kodi can invalidate its InfoTag during a real Stop. Unknown state is
        # not evidence of foreign playback, and never authorizes another Stop.
        if time.monotonic()>value['deadline'] and not confirmed59:
            value['phase']='failed';_save(value);_trace('PLAYER_UNAVAILABLE',session)
        elif not value.get('player_wait47'):
            value['player_wait47']=True;_save(value);_trace('PLAYER_STATE_PENDING47',session)
        return True
    if playing and not any(_same(token,('live',item)) for item in allowed):
        # Foreign playback must neither receive stop nor a GUI navigation.
        if navigator is not None and getattr(navigator,'_exiting',False):navigator.close()
        value['phase']='failed';_save(value);_trace('FOREIGN_PLAYER',session);return True
    if value['phase']=='requested':
        if time.monotonic()<value['not_before']:return True
        # Commit before invoking native Stop; reentrant ticks cannot stop twice.
        value['phase']='stopping';_save(value)
        # Release the native overlay BEFORE scheduling Stop on a later tick.
        # Never wait on Player.stop while owning the live dialog.
        if navigator is not None and not navigator._closed:navigator.close()
        if playing:
            if not stop_owned(player,expected=token,reason=value.get('reason','USER_BACK')):
                value['phase']='failed';_save(value)
                if navigator is not None and not navigator._closed:navigator.close()
                _trace('OWNERSHIP_CHANGED',session);return True
        _trace('STOP_QUEUED',session)
        return True
    if player.isPlayingVideo() or (hasattr(player,'isPlaying') and player.isPlaying()):
        if time.monotonic()>value['deadline']:
            value['phase']='failed';_save(value)
            if navigator is not None and not navigator._closed:navigator.close()
            _trace('STOP_TIMEOUT',session)
            xbmcgui.Dialog().notification('XCMate','Live-TV konnte nicht beendet werden.')
        return True
    if value['phase']=='stopping':
        if navigator is not None and not navigator._closed:navigator.close()
        for key in ('XCMate.PrePlay.Request','XCMate.PrePlay.Ack','XCMate.PrePlay.Ready',SESSION,'XtreamMate.RemoteCommand'):
            raw=marker.getProperty(key)
            if key=='XtreamMate.RemoteCommand' or raw in [item['nonce'] for item in allowed] or (session_from_property(raw) or {}).get('nonce') in [item['nonce'] for item in allowed]:marker.clearProperty(key)
        value['phase']='home';_save(value);_trace('STOP_DONE',session)
        return True  # Native close returns before navigation on a later tick.
    if value.get('recovery46')=='LATE_ACK_VERIFIED':
        from live_recovery46 import gui_available
        if not gui_available():return True
    from live_return47 import guard as return_guard47
    status47,fresh47=return_guard47(value)
    if status47!='READY':
        _trace('RETURN_'+status47+'47',session)
        return True
    value=fresh47
    from live_return59 import ready as return_ready59
    if not return_ready59(value):return True
    status47,fresh47=return_guard47(value)
    if status47!='READY':return True
    value=fresh47
    if getattr(xbmc.Monitor(),'abortRequested',lambda:False)():return True
    from live_trace48 import return_home as widget_return48
    returned48=widget_return48(value)
    if returned48 is None:return True
    value['phase']='complete';_save(value)
    if returned48:
        _trace('HOME_WIDGET_RETURN48',session);return True
    url='plugin://plugin.video.xtreammate/?'+urlencode(dict(action='xcmate_home',pid=session['pid']))
    from urllib.parse import urlsplit,parse_qs
    folder=urlsplit(xbmc.getInfoLabel('Container.FolderPath'))
    params=parse_qs(folder.query)
    same_home=(folder.scheme=='plugin' and folder.netloc=='plugin.video.xtreammate'
               and params.get('action')==['xcmate_home'] and params.get('pid')==[session['pid']])
    if same_home:
        # Reveal the existing Videos Home without issuing another GetDirectory.
        if not xbmc.getCondVisibility('Window.IsActive(videos)'):
            xbmc.executebuiltin('ActivateWindow(Videos)')
        _trace('HOME_REUSED',session)
    elif xbmc.getCondVisibility('Window.IsActive(videos)'):
        xbmc.executebuiltin('Container.Update('+url+',replace)')
    else:xbmc.executebuiltin('ActivateWindow(Videos,'+url+',return)')
    if not same_home:_trace('HOME_REQUESTED',session)
    return True


def poll(navigator=None):
    try:return _poll(navigator)
    except (AttributeError,RuntimeError,TypeError,ValueError,KeyError):
        # Kodi can invalidate InfoTags between isPlayingVideo and identity().
        # Hold this exit while pending; never terminate the background service.
        value=state()
        if not value:return False
        from live_return59 import stop_confirmed
        from exit_jobs import state as job_state59
        if time.monotonic()>value['deadline'] and not stop_confirmed(value,job_state59()):
            value['phase']='failed';_save(value)
            if navigator is not None and not navigator._closed:navigator.close()
        _trace('PLAYER_UNAVAILABLE',value['session']);return True
