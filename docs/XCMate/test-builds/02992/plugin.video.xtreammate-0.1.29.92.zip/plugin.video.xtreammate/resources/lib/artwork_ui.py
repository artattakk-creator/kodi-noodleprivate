"""Explicit IR-friendly artwork management; worker progress, no automatic move."""
from concurrent.futures import ThreadPoolExecutor
import threading
import os
from localization import tr


def job(function):
    import xbmc,xbmcgui
    cancel=threading.Event();lock=threading.Lock();latest={}
    def progress(**value):
        with lock:latest.clear();latest.update(value)
    pool=ThreadPoolExecutor(max_workers=1);future=pool.submit(function,cancel.is_set,progress)
    progress_dialog=xbmcgui.DialogProgress();progress_dialog.create(tr(35200),tr(35220))
    try:
        while not future.done():
            with lock:value=dict(latest)
            total=value.get('files',0);done=value.get('done',0)
            percent=int(100*done/total) if total and value.get('stage') not in ('INVENTORY','VERIFYING') else 0
            stage=value.get('stage','WORKING')
            phase={'INVENTORY':35233,'COPYING':35234,'VERIFYING':35235,'CLEANUP':35236}.get(stage)
            text=(tr(phase) if phase else stage)+' · '+str(done)+' / '+str(total)+' · '+str(value.get('done_bytes',value.get('bytes',0)))+' Bytes'
            progress_dialog.update(percent,text)
            if progress_dialog.iscanceled() or getattr(xbmc.Monitor(),'abortRequested',lambda:False)():
                cancel.set();return None  # Worker retains original files/journal.
            xbmc.Monitor().waitForAbort(.1)
        return future.result()
    finally:progress_dialog.close();pool.shutdown(wait=False,cancel_futures=True)


def _render(uri):
    import xbmcgui
    if not uri:return False
    class Probe(xbmcgui.WindowDialog):
        def __init__(self):
            super().__init__();self.addControls([xbmcgui.ControlImage(70,100,240,240,uri),xbmcgui.ControlLabel(70,350,1050,60,tr(35221))])
    window=Probe()
    try:
        window.show()
        return xbmcgui.Dialog().yesno(tr(35200),tr(35221),yeslabel=tr(35222),nolabel=tr(35223))
    finally:window.close()


def switch(mode,strategy='demand'):
    from artwork_gate import writer
    from artwork_config import choose,read
    with writer():
        current=read()
        if mode=='internal' and current.get('archive_mode',current['mode'])=='external':
            from artwork_vfs import StorageFailure
            raise StorageFailure('COPY_INCOMPLETE')
        return choose(mode,strategy=strategy)


def _pick():
    import xbmcgui
    from storage_sources import external_sources,kodi_sources
    dialog=xbmcgui.Dialog();kind=__import__('menu_icons45').select(dialog,tr(35204),[tr(35224),tr(35225),tr(38300)],default='image')
    if kind==2:
        target=_pick_android()
        if target:_prepare(target,shared=True)
        return None
    if kind not in (0,1):return None
    values=job(lambda cancel,progress:external_sources() if kind==0 else [row for row in kodi_sources() if row['path'].startswith('smb://')])
    if values is None:return None
    if kind==1:values.append(dict(label=tr(35226),path='smb://'))
    if not values:
        from artwork_vfs import StorageFailure
        raise StorageFailure('TARGET_NOT_BROWSABLE')
    index=__import__('menu_icons45').select(dialog,tr(35204),[v['label'] for v in values],default='image')
    if not 0<=index<len(values):return None
    return dialog.browseSingle(0,tr(35204),'files',defaultt=values[index]['path']) or None


def _pick_android():
    import xbmcgui
    from android_storage83 import candidates,measure
    from artwork_vfs import StorageFailure
    values=job(lambda cancel,progress:candidates())
    if values is None:return None
    if not values:raise StorageFailure('TARGET_SAF_REQUIRED')
    dialog=xbmcgui.Dialog()
    index=__import__('menu_icons45').select(dialog,tr(38300),[row['label'] for row in values],default='image')
    if not 0<=index<len(values):return None
    target=dialog.browseSingle(3,tr(38300),'files',defaultt=values[index]['path'])
    if not target:return None
    # Listing is no permission grant. A returned URI or vanished mount fails.
    if job(lambda cancel,progress:measure(target,'TARGET',require=True)) is None:return None
    return target


def _prepare(target, shared=False):
    import xbmcgui
    import artwork_migration as migration
    from android_artwork87 import preflight
    dialog=xbmcgui.Dialog()
    shared=shared or target.startswith(('/storage/emulated/','/sdcard/'))
    if shared:
        result=job(lambda cancel,progress:preflight(target))
        if result is None:return
        dialog.textviewer(tr(38301),_storage_text(result['rows']))
        if not dialog.yesno(tr(38300),tr(38302)):return
    result=job(lambda cancel,progress:migration.begin(target,shared=shared,confirmed=shared,strict87=shared))
    if result is not None:dialog.ok(tr(35200),tr(35216))


def _storage_text(rows):
    import json
    # Byte-accurate, redacted read-only receipts. No full filesystem paths,
    # mount sources, tokens, labels, SMB credentials or provider addresses.
    return tr(38303)+'\n\n'+json.dumps(rows,ensure_ascii=False,indent=2)


def _manage():
    import xbmcgui
    from artwork_config import read
    from artwork_vfs import StorageFailure
    import artwork_migration as migration
    dialog=xbmcgui.Dialog()
    while True:
        value=read()
        labels=[tr(i) for i in (35201,35202,35203,35204,35205,35206,35207,35208,35209,35210,35211,35212,35213,35232,35700,35701,38300,38301)]
        labels.append('Speicher und Artwork-Bestand (nur lesen)')
        choice=__import__('menu_icons45').select(dialog,tr(35200)+' · '+value['mode'],labels,default='image')
        if choice<0:return
        try:
            if choice==18:
                data88=job(lambda cancel,progress:__import__('storage_report88').collect())
                if data88 is not None:dialog.textviewer('Artwork-Speicher',__import__('json').dumps(data88,ensure_ascii=False,indent=2))
            elif choice==0:
                from artwork_status import collect,text
                data=job(collect)
                if data is not None:dialog.textviewer(tr(35200),text(data))
            elif choice in (1,2):
                mode='dynamic' if choice==1 else 'internal'
                if not dialog.yesno(tr(35200),tr(35214 if mode=='dynamic' else 35215)):continue
                if mode=='internal' and value.get('archive_mode',value['mode'])=='external':
                    job(lambda cancel,progress:migration.begin('INTERNAL'));dialog.ok(tr(35200),tr(35216))
                else:job(lambda cancel,progress:switch(mode))
            elif choice==3:
                target=_pick()
                if target:_prepare(target)
            elif choice==4:
                probe=job(lambda cancel,progress:migration.probe_image())
                if probe:
                    approved=_render(probe['uri'])
                    job(lambda cancel,progress:migration.remove_probe(probe))
                    if not approved:dialog.ok(tr(35200),tr(35223))
            elif choice==5:job(migration.inventory)
            elif choice==6:job(migration.copy)
            elif choice==7:
                def check(cancel,progress):return migration.verify(cancel,progress)
                if job(check):
                    uri=job(lambda cancel,progress:migration.display_candidate())
                    probe=None
                    if not uri:
                        probe=job(lambda cancel,progress:migration.probe_image());uri=probe['uri'] if probe else ''
                    approved=_render(uri)
                    if probe:job(lambda cancel,progress:migration.remove_probe(probe))
                    job(lambda cancel,progress:migration.approve_render(approved))
            elif choice==8:
                if dialog.yesno(tr(35200),tr(35217)):job(migration.activate)
            elif choice==9:
                state=job(lambda cancel,progress:migration.status())
                if state and state['stage'] in ('ACTIVE','CLEANUP_PAUSED') and dialog.yesno(tr(35200),tr(35218,state['files'],state['bytes'])):
                    if dialog.yesno(tr(35200),tr(35219)):
                        result=job(lambda cancel,progress:migration.cleanup_report(state['transfer'],cancel,progress))
                        if result:
                            import json
                            dialog.textviewer(tr(35210),json.dumps(result,ensure_ascii=False,indent=2))
            elif choice==10:
                if value['mode']=='dynamic':dialog.ok(tr(35200),tr(35214));continue
                if dialog.yesno(tr(35200),tr(35227)):
                    def preload(cancel,progress):
                        from artwork_config import choose,locked,_write
                        from artwork_gate import writer
                        import uuid
                        with writer():
                            with locked():
                                config=read()
                                if config['mode']=='dynamic':return False
                                config['strategy']='all';config['origin']='USER';config['preload_generation']=uuid.uuid4().hex;_write(config)
                        return True
                    job(preload)
            elif choice==11:
                if dialog.yesno(tr(35200),tr(35237 if value.get('reserve_policy')=='adaptive' else 35228)):
                    def adaptive(cancel,progress):
                        from artwork_config import locked,_write
                        with locked():
                            config=read();config['reserve_policy']='fixed' if value.get('reserve_policy')=='adaptive' else 'adaptive';_write(config)
                    job(adaptive)
            elif choice==12:
                if dialog.yesno(tr(35200),tr(35229)):
                    from metadata_export import export
                    result=job(export)
                    if result:
                        import json
                        dialog.textviewer(tr(35213),json.dumps(result,ensure_ascii=False,indent=2))
            elif choice==13:
                import xbmcaddon
                from utils import setting_bool
                old=setting_bool('media_art_paused',False)
                if dialog.yesno(tr(35200),tr(35232)):
                    xbmcaddon.Addon().setSetting('media_art_paused','false' if old else 'true')
            elif choice==14:
                from artwork_status import cleanup
                cleanup()
            elif choice==15:
                from artwork_status import collect
                data=job(collect)
                if data:
                    import json
                    dialog.textviewer(tr(35701),json.dumps(data,ensure_ascii=False,indent=2))
            elif choice==16:
                target=_pick_android()
                if target:_prepare(target,shared=True)
            elif choice==17:
                from android_storage83 import inventory,public
                rows=job(lambda cancel,progress:public(inventory()))
                if rows is not None:dialog.textviewer(tr(38301),_storage_text(rows))
        except Exception as error:
            from artwork_errors83 import show
            show(error,dialog,choice)


def manage():
    from window_navigation import ownership
    with ownership() as acquired:
        if acquired:_manage()
