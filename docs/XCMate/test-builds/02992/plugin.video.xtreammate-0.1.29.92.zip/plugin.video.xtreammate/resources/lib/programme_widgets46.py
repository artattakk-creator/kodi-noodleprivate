"""Existing Live widget -> same event DTO/art as the graphical programme view."""
import os
from localization import tr

def decorate(value,portal,channel,info):
 from programme_events46 import from_info,summary
 from programme_art46 import cached
 event=from_info(portal,channel,info or {});art=cached(event)
 from programme_flow48 import trace
 trace('LISTITEM',event,art.get('code','PENDING'))
 from programme_assets47 import station_image
 logo=value['art'].get('thumb','');real=station_image(logo)
 image=art.get('image') or event['placeholder']
 # Native BINGIE layouts do not consume our optional logo-overlay property.
 # Keep a real station image visible when no verified programme image exists.
 # The graphical view retains the neutral programme image separately.
 from programme_image69 import eligible,proof
 actual=eligible(art,event)
 display=image if actual else logo if real else image
 value['art'].update(poster=display,thumb=display,landscape=display,fanart=image,icon=logo if real else image)
 props=value['props'];props['XCMate.ArtProof69']=proof(art) if actual else '';props.update({'XCMate.ProgrammeKey46':event['key'],'XCMate.ProgrammeImage46':image,'XCMate.ProgrammeLogo46':logo if real else '', 'XCMate.ProgrammeChannel46':event['channel'], 'XCMate.ProgrammeTitle46':event['title'] or tr(36102), 'XCMate.ProgrammeTimes46':((info.get('now_time','')+' – '+info.get('now_end_time','')) if event['title'] else ''),'XCMate.ProgrammeNext46':info.get('next',''),'XCMate.ProgrammeDescription46':event.get('description',''),'XCMate.ProgrammePercent46':str(round(info['progress']*100)) if event['title'] and isinstance(info.get('progress'),(int,float)) else '0', 'XCMate.ProgrammeDetails46':event['details_url'], 'XCMate.ProgrammeArtCode46':art.get('code','PENDING')})
 if event['title']:value['info']['title']=event['title']
 props['XCMate.ProgrammeNextTimes48']=info.get('next_time','')+' – '+info.get('next_end_time','') if info.get('next') else ''
 props['XCMate.Provisional85']='true' if (art.get('provisional85') or art.get('match')=='PROVISIONAL_TV85') else ''
 if (art.get('provisional85') or art.get('match')=='PROVISIONAL_TV85'):props['XCMate.ProgrammeDescription46']='Bildvorschlag – Zuordnung nicht bestätigt.\n'+props['XCMate.ProgrammeDescription46']
 props['XCMate.ProgrammeKey47']=event['key']
 props['XCMate.ProgrammeNextStart47']=str(info.get('next_start',0))
 props['XCMate.ProgrammeDisplay47']='PROGRAMME_IMAGE' if actual else 'STATION_LOGO' if real else 'NEUTRAL_NO_LOGO'
 props['XCMate.ProgrammeArtSource57']=str(art.get('source',''))
 props['XCMate.ProgrammeArtCredit57']=str(art.get('attribution',''))
 props['XCMate.ProgrammeImageScope57']=str(art.get('image_scope57',''))
 if actual and art.get('image_scope57')=='series_fallback':
  note=tr(36542)
  props['XCMate.ProgrammeDescription46']=note+'\n'+props['XCMate.ProgrammeDescription46']
  value['info']['plot']=note+'\n'+value['info']['plot']
 props['channellogo']=logo if real else ''
 value['info']['plot']=summary(event)+'\n\n'+value['info']['plot']
 value['menus46']=[(tr(36100),'RunPlugin('+event['details_url']+')')]
 value['_programme46']=event
 return value
