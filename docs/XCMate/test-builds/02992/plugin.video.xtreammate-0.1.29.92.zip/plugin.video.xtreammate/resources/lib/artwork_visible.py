"""Bounded visible-image approval/cache; no external filesystem/DNS on GUI.

Dynamic mode passes approved provider URLs to Kodi's texture loader. XCMate
never downloads/archives them; Kodi may cache textures itself. Public-address
DNS validation is background-only, cached briefly, with no provider URL logs.
"""
import collections
import ipaddress
import queue
import socket
import threading
import time
from urllib.parse import urlsplit

_lock=threading.Lock();_values=collections.OrderedDict();_pending=set();_revision=0
_queues={'dynamic':queue.Queue(maxsize=128),'external':queue.Queue(maxsize=128)}
_threads={}
_dns_cache=collections.OrderedDict()
KODI_OPTIONS='|redirect-limit=0&connection-timeout=3&failonerror=true'


def syntactic(url):
    from media_art import valid_source
    if not valid_source(url) or '\\' in url or '|' in url:return False
    try:
        p=urlsplit(url)
        if p.username is not None or p.password is not None:return False
        if p.hostname.lower()=='localhost' or p.hostname.lower().endswith(('.localhost','.local','.internal')):return False
        try:return ipaddress.ip_address(p.hostname).is_global
        except ValueError:return '.' in p.hostname
    except (ValueError,AttributeError):return False


def public_dns(url):
    if not syntactic(url):return False
    p=urlsplit(url);key=(p.hostname,p.port or (443 if p.scheme=='https' else 80))
    with _lock:
        prior=_dns_cache.get(key)
        if prior and prior[0]>time.monotonic()+(10 if prior[1] else 0):return prior[1]
    try:
        values=socket.getaddrinfo(key[0],key[1],type=socket.SOCK_STREAM)
        approved=bool(values) and all(ipaddress.ip_address(value[4][0]).is_global for value in values)
        from dns_verdict78 import record
        record(key,not values)
    except OSError:
        approved=False
        from dns_verdict78 import record
        record(key,True)
    except ValueError:
        approved=False
        from dns_verdict78 import record
        record(key,False)
    with _lock:
        _dns_cache[key]=(time.monotonic()+(30 if approved else 5),approved)
        _dns_cache.move_to_end(key)
        while len(_dns_cache)>128:_dns_cache.popitem(last=False)
    return approved


def _process(kind,key,payload):
    if kind=='dynamic':
        approved=public_dns(payload)
        return payload+KODI_OPTIONS if approved else ''
    storage,ident=payload
    from artwork_vfs import image_valid
    data=storage.read(ident,65536)
    return storage.make_display_uri(ident) if image_valid(data) else ''


def _run(kind):
    global _revision
    work=_queues[kind]
    while True:
        try:key,payload=work.get(timeout=2)
        except queue.Empty:
            with _lock:
                if work.empty():_threads.pop(kind,None);return
            continue
        try:
            try:value=_process(kind,key,payload)
            except Exception:value=''
            with _lock:
                fresh=key not in _values
                previous=_values.get(key,(0,''))[1]
                expires=time.monotonic()+(30 if value else 5)
                if kind=='dynamic' and value:
                    parsed=urlsplit(payload);dns=_dns_cache.get((parsed.hostname,parsed.port or (443 if parsed.scheme=='https' else 80)))
                    if not dns or not dns[1]:value=''
                    else:expires=min(expires,dns[0])
                _values[key]=(expires,value)
                _values.move_to_end(key);_pending.discard(key)
                if previous!=value:_revision+=1
                while len(_values)>512:_values.popitem(last=False)
            if kind=='dynamic' and (fresh or previous!=value):
                from art_diagnostics import publish
                publish('transfer','DYNAMIC_URL_APPROVED' if value else 'DYNAMIC_SOURCE_UNAVAILABLE')
        finally:work.task_done()


def lookup(kind,key,payload):
    with _lock:
        value=_values.get(key)
        now=time.monotonic()
        # Revalidate ten seconds before expiry; never extend DNS approval TTL.
        if value and value[0]>now+(10 if value[1] else 0):return value[1]
        if key not in _pending:
            try:_queues[kind].put_nowait((key,payload));_pending.add(key)
            except queue.Full:return value[1] if value and value[0]>now else ''
        thread=_threads.get(kind)
        if thread is None or not thread.is_alive():
            thread=threading.Thread(target=_run,args=(kind,),name='XCMate-visible-'+kind,daemon=True)
            _threads[kind]=thread;thread.start()
        return value[1] if value and value[0]>now else ''


def dynamic(url):
    if not syntactic(url):return ''
    return lookup('dynamic',('dynamic',url),url)


def external(storage,ident):
    return lookup('external',('external',storage.resolve_target(),ident),(storage,ident))


def revision():
    with _lock:return _revision


def retain_displayed(item,prior,current):
    """Keep an already displayed texture while its exact URL is pending.

    This does not admit an expired URI to a new item. Definitive DNS failure
    removes pending and forces the placeholder; no TTL/security bypass.
    """
    from artwork_config import persistent
    if persistent():return current
    from media_art import sources
    poster,fanart=sources(item);result=dict(current)
    with _lock:
        for url,fields in ((poster,('poster','thumb','icon','landscape')),(fanart,('fanart','landscape'))):
            if url and ('dynamic',url) in _pending:
                approved=_values.get(('dynamic',url),(0,''))[1]
                if approved==url+KODI_OPTIONS:
                    for field in fields:
                        if prior.get(field)==approved:result[field]=approved
    return result
