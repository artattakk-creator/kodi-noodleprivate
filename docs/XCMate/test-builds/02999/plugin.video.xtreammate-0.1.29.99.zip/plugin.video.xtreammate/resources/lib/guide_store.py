"""Persistent 7-calendar-day history / up-to-20-future-day master guide.

Only local normalized cache is imported. Failed/shorter imports retain future
programmes outside the new source window. No GUI callback performs an import.
"""
from localization import tr
import datetime
import hashlib
import json
import os
import sqlite3
import time

MAX_EVENTS=200000


def path():
    from utils import addon_data_dir
    return os.path.join(addon_data_dir(),'guide_v1.sqlite')


def connect(filename=None,write=False):
    existed=os.path.isfile(filename or path())
    if not existed:
        from import_budget import check_space
        check_space(filename or path())  # Never poison a new path with an empty DB on reserve failure.
    db=sqlite3.connect(filename or path(),timeout=2)
    db.row_factory=sqlite3.Row
    if existed:
        if write:
            from guide_publish44 import require
            try:require(db)
            except Exception:db.close();raise
        return db
    db.execute('PRAGMA auto_vacuum=INCREMENTAL')
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA max_page_count=2147483646')
    db.executescript('''CREATE TABLE IF NOT EXISTS guide_meta(pid TEXT PRIMARY KEY,revision TEXT,updated REAL);
      CREATE TABLE IF NOT EXISTS guide_alias(pid TEXT,alias TEXT,cid TEXT,PRIMARY KEY(pid,alias));
      CREATE TABLE IF NOT EXISTS programmes(pid TEXT,cid TEXT,start INTEGER,stop INTEGER,
        title TEXT,description TEXT,source INTEGER,PRIMARY KEY(pid,cid,start,stop));
      CREATE INDEX IF NOT EXISTS guide_window ON programmes(pid,cid,start);
      CREATE INDEX IF NOT EXISTS guide_source ON programmes(pid,cid,source,start);
      CREATE INDEX IF NOT EXISTS guide_expiry ON programmes(stop);''')
    if not existed:
        from guide_publish44 import initialize
        initialize(db)
    return db


def import_cache(pid,cache,revision='',now=None,filename=None,*,trusted_feed=False,source_records=None):
    from epg_views import _as_int
    from epg_events import deduplicate
    now=int(time.time() if now is None else now)
    right46=__import__('programme_index46').bounds(now)[1]
    if not isinstance(cache,dict) or not cache: return False
    db=connect(filename,write=True)
    from programme_store46 import Stage as ProgrammeStage46
    metadata46=ProgrammeStage46(pid,__import__('uuid').uuid4().hex,0,filename,source_records=(source_records or {}) if trusted_feed else None)
    committed46=False
    try:
        from guide_publish44 import require
        require(db)
        with db:
            db.execute('CREATE TEMP TABLE incoming(cid TEXT,start INTEGER,stop INTEGER,title TEXT,description TEXT,source INTEGER,PRIMARY KEY(cid,start,stop))')
            for alias,events in cache.items():
                if not isinstance(events,list): continue
                canonical=None
                for event in deduplicate(events):
                    if not isinstance(event,dict): continue
                    start=_as_int(event.get('start_timestamp'));stop=_as_int(event.get('stop_timestamp'))
                    title=str(event.get('name') or event.get('title') or '')[:512]
                    if start<=0 or stop<=start or stop<=day_window(-7,now)[0] or not title: continue
                    if start>=right46:continue
                    metadata46.add(dict(event,channel=str(event.get('channel') or alias)))
                    cid=str(event.get('channel') or alias)
                    canonical=cid
                    try: source=int(event.get('_source_index',0))
                    except (ValueError,TypeError): source=0
                    # Canonical XMLTV rows win over a stale stream alias with
                    # the same channel/time, independent of dict iteration.
                    db.execute(('INSERT OR REPLACE' if str(alias)==cid else 'INSERT OR IGNORE')+' INTO incoming VALUES(?,?,?,?,?,?)',
                        (cid,start,stop,title,str(event.get('descr') or event.get('description') or '')[:4096],source))
                if canonical: db.execute('INSERT OR IGNORE INTO guide_alias VALUES(?,?,?)',(pid,str(alias),canonical))
            from epg_events import clean_stage
            clean_stage(db,'incoming')
            count=db.execute('SELECT count(*) FROM incoming').fetchone()[0]
            if not count: return False
            if count>MAX_EVENTS: raise ValueError('guide index budget')
            from guide_publish44 import publish
            if trusted_feed:
                from guide_publish44 import source_id
                for (index,) in db.execute('SELECT DISTINCT source FROM incoming ORDER BY source').fetchall():
                    record=(source_records or {}).get(index,{})
                    publish(db,pid,'incoming','source=?',(index,),source=source_id(record,index),rank=index,revision=revision,now=now)
            else:publish(db,pid,'incoming',revision=revision,now=now)
        committed46=True
        return True
    finally:
        db.close();metadata46.finish(committed46)


def refresh(portal,filename=None):
    from epg_gate46 import access as refresh_access46
    if refresh_access46(filename or path()) not in ('READY','NOT_CREATED'):return False
    from epg import load_cache
    from epg_status import revision,read
    rev=revision(portal['id'])+'|'+str(read(portal['id']).get('cache',{}).get('last_success',0))
    # Revision Home properties disappear on restart. A saved populated DB is
    # still useful; a process-local first refresh imports once, never per key.
    db=connect(filename)
    try: prior=db.execute('SELECT revision FROM guide_meta WHERE pid=?',(portal['id'],)).fetchone()
    finally: db.close()
    if prior:return False
    return import_cache(portal['id'],load_cache(portal['id']),rev,filename=filename)


def day_window(day,now=None):
    """Local calendar midnights; DST days are 23/25 hours, not always 86400s."""
    today=datetime.date.fromtimestamp(time.time() if now is None else now)
    date=today+datetime.timedelta(days=int(day))
    def midnight(d): return int(time.mktime((d.year,d.month,d.day,0,0,0,0,0,-1)))
    return midnight(date),midnight(date+datetime.timedelta(days=1))


def events(pid,epg_id,start,stop,offset=0,limit=100,filename=None):
    db=connect(filename)
    try:
        alias=db.execute('SELECT cid FROM guide_alias WHERE pid=? AND alias=?',(pid,str(epg_id))).fetchone()
        cid=alias[0] if alias else str(epg_id)
        where='pid=? AND cid=? AND start<? AND stop>?'
        args=(pid,cid,stop,start)
        # Legacy rows are filtered defensively without rewriting user caches.
        # Stream one channel/day, retaining only the requested unique page.
        from epg_events import deduplicate
        page=[];total=0;pending=[];offset=max(0,int(offset));limit=min(100,max(1,int(limit)))
        def publish(batch):
            nonlocal total
            for row in deduplicate(batch,channel=cid):
                if offset<=total<offset+limit: page.append(row)
                total+=1
        for raw in db.execute('SELECT * FROM programmes WHERE '+where+' ORDER BY start,stop',args):
            row=dict(raw)
            if pending and row['start']-pending[-1]['start']>120:
                publish(pending);pending=[]
            if len(pending)>=512: raise ValueError('EPG dense interval budget')
            pending.append(row)
        publish(pending)
        return page,total
    finally: db.close()


def horizon(pid,epg_id=None,filename=None):
    db=connect(filename)
    try:
        where='pid=?';args=[pid]
        if epg_id is not None:
            alias=db.execute('SELECT cid FROM guide_alias WHERE pid=? AND alias=?',(pid,str(epg_id))).fetchone()
            where+=' AND cid=?';args.append(alias[0] if alias else str(epg_id))
        row=db.execute('SELECT min(start),max(stop),count(*) FROM programmes WHERE '+where,args).fetchone()
        return dict(first_event=row[0],last_event=row[1],programmes=row[2])
    finally: db.close()


def status_lines(portal,filename=None):
    from epg_sources import configuration
    from epg_status import read,source_key
    from epg_preview import safe_name
    config=configuration(portal['id']);state=read(portal['id'])
    db=connect(filename)
    try:
        rows=db.execute('SELECT source,min(start),max(stop),count(*) FROM programmes WHERE pid=? GROUP BY source',(portal['id'],)).fetchall()
    finally: db.close()
    lines=[tr(32558),
           tr(32559)]
    for source,first,last,count in rows:
        source_record=None
        if source>0 and source<=len(config['sources']): source_record=config['sources'][source-1]
        name=safe_name(source_record.get('name')) if source_record else tr(32560) if source==0 else tr(32561)
        entry=state.get(source_key(source_record) if source_record else 'provider',{})
        success=entry.get('last_success')
        lines+=['',tr(32562).format(name,count),
                tr(32563).format(time.strftime(tr(32585),time.localtime(first)),time.strftime(tr(32585),time.localtime(last))),
                tr(32564)+(time.strftime(tr(32585),time.localtime(success)) if success else tr(32565)),
                tr(32566)+str(entry.get('code',tr(32567)))]
    if not rows: lines.append(tr(32568))
    from guide_publish44 import diagnose
    lines+=['',json.dumps(diagnose(filename or path(),portal['id']),ensure_ascii=False)]
    from epg_dedup_diagnostics import read as dedup_reports
    reports=dedup_reports()
    if reports:
        lines+=['',tr(32787),json.dumps(reports[-8:],ensure_ascii=False,indent=2)]
    return lines


def covers_active(portal,hours=24):
    """Check actual saved day-guide coverage, not the four-event fast snapshot."""
    if portal.get('type')!='xtream': return False
    from stream_epg import active_streams
    from epg_sources import configuration
    streams=active_streams(portal);mappings=configuration(portal['id'])['mappings']
    now=int(time.time());end=now+hours*3600;seen=False
    db=connect()
    try:
        for row in streams:
            seen=True;alias=mappings.get(row['sid']) or row['sid']
            target=db.execute('SELECT cid FROM guide_alias WHERE pid=? AND alias=?',(portal['id'],alias)).fetchone()
            cid=target[0] if target else mappings.get(row['sid']) or row.get('epg_channel_id') or row['sid']
            covered=now
            for begin,stop in db.execute('SELECT start,stop FROM programmes WHERE pid=? AND cid=? AND start<? AND stop>? ORDER BY start',
                                         (portal['id'],cid,end,now)):
                if begin>covered+60: break
                covered=max(covered,stop)
                if covered>=end: break
            if covered<end: return False
        return seen
    finally: db.close()
