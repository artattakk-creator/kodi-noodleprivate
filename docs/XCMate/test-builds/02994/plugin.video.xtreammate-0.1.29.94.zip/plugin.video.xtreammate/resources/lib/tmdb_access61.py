"""Explicit private token actions. Never display paths, contents or raw errors."""
import hashlib
from localization import tr

def activate(addon,automatic=False):
    from utils import setting_bool
    if automatic and setting_bool('programme_tmdb_optout77',False):return False
    from programme_consent77 import decision
    decision('tmdb',True,addon)
    addon.setSetting('programme_tmdb46','true')
    addon.setSetting('tmdb_research43','true')
    from programme_refresh63 import request
    request()

def imported(choice,dialog,addon,gui,tokens):
    from token_write64 import note,read_destination
    note('SOURCE_SELECTION')
    if choice==7:
        raw=dialog.input(tr(36661),type=getattr(gui,'INPUT_ALPHANUM',0),option=getattr(gui,'ALPHANUM_HIDE_INPUT',1))
        if not raw:return
        raw=raw.encode('utf-8');value=tokens.validate(raw)
    else:
        source=dialog.browseSingle(1,tr(36621),'files','.txt',False,False)
        if not source:return
        from tmdb_import63 import selected
        progress=None
        try:
            factory=getattr(gui,'DialogProgress',None)
            if factory is not None:
                progress=factory();progress.create(tr(36620),tr(36663))
            try:
                raw=selected(source,cancel=(lambda:progress.iscanceled()) if progress else lambda:False)
            except tokens.TokenError as error:
                error.stage='VFS_READ';note('VFS_READ','FAILED');raise
            note('VFS_READ')
        finally:
            if progress:progress.close()
        tokens.validate(raw);note('UTF8_FORMAT_VALIDATION')
    target=tokens.location()
    from token_destination65 import pre_read,Cancelled65
    try:old=pre_read(tokens,target,dialog,gui)
    except Cancelled65:return
    if choice==7:
        if old is None:
            addon.setSetting('tmdb_read_token43',value)
            tokens.effective_tmdb_read_token(force=True)
            activate(addon,automatic=True)
            dialog.ok(tr(36620),tr(36628));return
        dialog.ok(tr(36620),tr(36662))
    expected=hashlib.sha256(old).hexdigest() if old is not None else None
    if old is not None and not dialog.yesno(tr(36620),tr(36627),defaultbutton=getattr(gui,'DLG_YESNO_NO_BTN',10)):return
    if choice==6 and not dialog.yesno(tr(36620),tr(36664),defaultbutton=getattr(gui,'DLG_YESNO_NO_BTN',10)):return
    result=tokens.import_bytes(raw,expected,target=target)
    if tokens.location()!=target:raise tokens.TokenError('TOKEN_CHANGED')
    activate(addon,automatic=True)
    dialog.ok(tr(36620),tr(36628)+'\n'+tr(36665 if choice==6 else 36666)+('\n'+tr(36672) if result=='IMPORTED_SYNC_WARNING' else ''))

def show():
    import xbmcaddon,xbmcgui
    from menu_icons45 import select
    import tmdb_token61 as tokens
    dialog=xbmcgui.Dialog();addon=xbmcaddon.Addon()
    while True:
        state=tokens.status()
        labels=[tr(36621),tr({'FILE_VALID':36622,'FILE_MISSING':36623}.get(state,36624)),tr(36600),tr(36625),tr(36640),tr(36626),tr(36660),tr(36661),tr(38100)]
        choice=select(dialog,tr(36620),labels,actions=['settings','information','settings','check','back','check','settings','settings','check'])
        if not isinstance(choice,int) or not 0<=choice<len(labels) or choice==4:return
        if choice==8:
            from programme_diagnostic74 import show as diagnostic74
            diagnostic74()
        elif choice in (0,6,7):
            try:imported(choice,dialog,addon,xbmcgui,tokens)
            except (tokens.TokenError,OSError,UnicodeError) as exc:
                code=exc.code if isinstance(exc,tokens.TokenError) else 'TOKEN_UNREADABLE'
                stage=getattr(exc,'stage','UTF8_FORMAT_VALIDATION' if code=='TOKEN_FORMAT' else 'SOURCE_SELECTION')
                dialog.ok(tr(36620),tr(36674 if getattr(exc,'committed',False) else 36629,code)+'\n'+tr(36673,stage)+' / '+getattr(exc,'subcode','NONE')+'\n'+tr(36667))
        elif choice==1:
            from token_write64 import diagnostic
            detail=diagnostic(tokens)
            dialog.ok(tr(36620),labels[1]+'\n'+detail['code']+' / '+detail['stage']+'\n'+tr(36630))
        elif choice==2:
            from tmdb_connection60 import launch
            launch()
        elif choice==3:
            if dialog.yesno(tr(36620),tr(36631),defaultbutton=getattr(xbmcgui,'DLG_YESNO_NO_BTN',10)):activate(addon)
        elif choice==5:
            if not dialog.yesno(tr(36620),tr(36632),defaultbutton=getattr(xbmcgui,'DLG_YESNO_NO_BTN',10)):continue
            from programme_consent77 import decision
            decision('tmdb',False,addon)
