"""Exact-event bookmarks and existing owner-pump tuning, no alternate player."""
import hashlib,json,math,os,re,tempfile,time
from pathlib import Path
def bookmark_id(event):
 return hashlib.sha256(json.dumps([str(event['pid']),str(event['sid']),int(event['start']),int(event['stop'])]).encode()).hexdigest()
def toggle(event,cancel=lambda:False):
 return __import__('reminder_bridge89').toggle(event,cancel)

def bookmark(event,cancel=lambda:False,wanted=None):
 from reminder_transaction95 import writing
 from utils import addon_data_dir
 if not event.get('sid') or not 0<int(event.get('start',0))<int(event.get('stop',0)):raise ValueError('BOOKMARK_INVALID')
 path=Path(addon_data_dir())/'guide_bookmarks_v1.json'
 with writing(timeout=.2):
  if cancel():raise InterruptedError('CANCELLED')
  if path.is_symlink() or path.exists() and path.stat().st_size>1024*1024:raise ValueError('BOOKMARK_UNSAFE')
  try:values=json.loads(path.read_bytes())
  except FileNotFoundError:values={}
  if not isinstance(values,dict):raise ValueError('BOOKMARK_INVALID')
  tag=bookmark_id(event);added=tag not in values if wanted is None else bool(wanted)
  if added:values[tag]={k:event[k] for k in ('pid','sid','start','stop','title')}
  else:values.pop(tag)
  raw=json.dumps(values,ensure_ascii=False,separators=(',',':')).encode()
  if len(raw)>1024*1024:raise ValueError('BOOKMARK_LIMIT')
  fd,tmp=tempfile.mkstemp(prefix='.bookmark88-',dir=path.parent)
  try:
   os.fchmod(fd,0o600)
   with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
   if cancel():raise InterruptedError('CANCELLED')
   os.replace(tmp,path)
   directory=os.open(path.parent,os.O_RDONLY)
   try:os.fsync(directory)
   finally:os.close(directory)
   if path.read_bytes()!=raw:raise OSError('BOOKMARK_READBACK')
  finally:
   if os.path.exists(tmp):os.unlink(tmp)
  return added
def timeline(event,now=None):
 now=time.time() if now is None else now;start=event.get('start',0);stop=event.get('stop',0)
 if not 0<start<stop:return '',0
 times=time.strftime('%H:%M',time.localtime(start))+'–'+time.strftime('%H:%M',time.localtime(stop))
 minutes=max(0,math.ceil((stop-now)/60));duration=max(1,math.ceil((stop-start)/60))
 state='beginnt in '+str(max(0,math.ceil((start-now)/60)))+' Min.' if now<start else 'beendet' if now>=stop else 'noch '+str(minutes)+' Min.'
 return times+' · '+str(duration)+' Min. · '+state,max(0,min(100,(now-start)*100/(stop-start)))
def tmdb_source(source):
 return str(source).startswith('tmdb') or source=='agent_tmdb'


def tmdb_id(value):
 if not tmdb_source(value.get('source')) or value.get('provisional85'):
  return None
 raw=value.get('provider_id')
 if type(raw) is int or isinstance(raw,str) and len(raw)<=12 and raw.isascii() and raw.isdecimal():
  ident=int(raw)
  return ident if 0<ident<10**12 else None
 return None


def _rating_text(score):
 if type(score) not in (int,float) or not 0<score<=10:return ''
 return 'TMDB '+format(score,'.1f').replace('.',',')+'/10'

def rating(value):
 votes=value.get('vote_count88')
 if not tmdb_source(value.get('source','')) or value.get('provisional85') or type(votes) is not int or votes<=0:return ''
 return _rating_text(value.get('vote_average88'))

def xmltv_tmdb(event):
 ident=event.get('xmltv_tmdb_id')
 if not isinstance(ident,str) or not re.fullmatch(r'(?:tv|movie)/[1-9][0-9]{0,11}',ident):ident=''
 scope={'tv':'Serie','movie':'Film'}.get(ident.partition('/')[0],'')
 return ident,_rating_text(event.get('xmltv_tmdb_score')) if ident else '',scope

def tune(parent,portal,channel):
 if parent is None:return False
 sid=str(channel.get('sid',''))
 if not sid or __import__('station_rows88').header(channel):return False
 if hasattr(parent,'_entry_player') and hasattr(parent,'_play_request'):
  from guide_playback import request
  from window_lifecycle import capture
  parent._play_request=request(portal,channel,parent._entry_player,capture(parent))
  parent._leaving=True;parent._leave_after=time.monotonic()+.15
  parent._generation+=1
  pending=getattr(parent,'_pending_future',None)
  if pending:pending.cancel()
  parent._pending_future=None;parent._pending_apply=None
  return True
 if hasattr(parent,'_tune') and hasattr(parent,'index'):
  target=parent.index.by_sid.get(sid)
  if target is not None:parent._tune(target);return True
 return False
