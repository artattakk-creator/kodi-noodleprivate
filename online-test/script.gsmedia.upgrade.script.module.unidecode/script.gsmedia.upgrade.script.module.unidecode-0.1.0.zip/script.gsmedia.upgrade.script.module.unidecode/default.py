# First-party inert Kodi dependency resolver; no side effects.
