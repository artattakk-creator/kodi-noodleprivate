# Inert native dependency bridge. No side effects.
