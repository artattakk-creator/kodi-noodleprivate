"""Read-only views of the successfully published guide_v1 snapshot.

Shared by grid, live/mini snapshots and widgets. No importer, DB creation,
provider request or independent persistent cache. Connections stay on the caller
worker; aliases and programmes are read in one SQLite transaction.
"""
import os
import sqlite3
import time
from urllib.parse import quote
from programme_read47 import scoped


def channel_keys(channel, mappings):
    extra=channel.extra if hasattr(channel,'extra') else channel
    sid=str(extra.get('stream_id',extra.get('sid','')))
    provider=str(getattr(channel,'tvg_id','') or extra.get('epg_channel_id') or extra.get('tvg_id') or extra.get('xmltv_id') or '')
    from epg_binding48 import view_mappings
    manual=(view_mappings(mappings) or {}).get(sid)
    return sid,([str(manual)] if manual else list(dict.fromkeys(k for k in (sid,provider) if k)))


class View(dict):
    def __init__(self):
        super().__init__();self.canonical={};self.revision=None;self.code='NOT_CREATED';self.channels={};self.provider_fallback=set()

    def channel(self,sid):
        """A sender's aliases cannot collide with another sender's source."""
        return self.channels.setdefault(str(sid),View())

    def add(self,sid,ident,cid,rows):
        channel=self.channel(sid);channel[ident]=rows;channel.canonical[ident]=cid
        # Keep the original dictionary surface for single-channel/old callers.
        self.setdefault(ident,rows);self.canonical.setdefault(ident,cid)


def for_channel(cache,sid):
    """Select exact sender rows in a local View; legacy dictionaries pass through."""
    if isinstance(cache,View) and cache.channels:
        return cache.channels.get(str(sid),{})
    return cache



def _read_binding(db,pid,channel,selected,start,stop,limit,*,strict=False,fallback=True):
    from epg_binding48 import read

    cid=selected['channel'];source=selected['source']
    rows=read(db,pid,cid,source,start,stop,limit,strict=strict)
    instant=max(start,time.time())
    need_now=instant<stop and not any(row['start_timestamp']<=instant<row['stop_timestamp'] for row in rows)
    if source=='agent' and fallback and not strict and (not rows or need_now):
        for provider_id in reversed(channel_keys(channel,{})[1]):
            provider=read(db,pid,provider_id,'provider',start,stop,limit)
            if not rows and provider:
                return provider_id,'provider',provider,True
            current=next((row for row in provider
                          if row['start_timestamp']<=instant<row['stop_timestamp']),None)
            if current:
                current=dict(current,_canonical=provider_id,_fused52=True)
                return cid,source,sorted([*rows,current],key=lambda row:row['start_timestamp']),True
    return cid,source,rows,False


def window(pid,channels,mappings,start,stop,limit=48,focus_sid='',history=False,budget=.4,text_only65=False,strict48=False,provider_fallback=True):
    from epg_binding48 import view_mappings
    mappings = view_mappings(mappings)
    # The exact full .64 metadata path stays authoritative for matching/art.
    # Only an explicit display request uses the RAM/text latency projection.
    if text_only65 and not strict48:
        return _text_window65(pid,channels,mappings,start,stop,limit,focus_sid,history,budget,True,provider_fallback)
    return _full_window65(pid,channels,mappings,start,stop,limit,focus_sid,history,budget,strict48=strict48,provider_fallback=provider_fallback)

def _full_window65(pid,channels,mappings,start,stop,limit=48,focus_sid='',history=False,budget=.4,strict48=False,provider_fallback=True):
    import guide_store
    filename=getattr(guide_store,'path',lambda:'')()
    if not filename or not os.path.isfile(filename):
        if strict48:return None
        from programme_snapshot47 import fallback_window
        return fallback_window(pid,channels,mappings,start,stop,limit)
    db=None
    started63=time.perf_counter()
    try:
        db=sqlite3.connect('file:'+quote(filename,safe='/')+'?mode=ro',uri=True,timeout=.05)
        db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON')
        deadline=time.monotonic()+budget
        db.set_progress_handler(lambda:int(time.monotonic()>deadline),1000)
        db.execute('BEGIN')
        meta=db.execute('SELECT * FROM guide_meta WHERE pid=?',(pid,)).fetchone()
        if not meta:
            if strict48:return None
            from programme_snapshot47 import fallback_window
            return fallback_window(pid,channels,mappings,start,stop,limit)
        view=View();view.code='OK';record=dict(meta)
        view.revision=(record.get('revision'),record.get('updated'))
        alias_rows89=__import__('epg_single89').aliases(db,pid,channels,mappings)
        tasks67=[]
        for channel in channels[:16]:
            sid,keys=channel_keys(channel,mappings)
            sender=view.channel(sid)
            for ident in keys:
                if ident in sender:continue
                from epg_binding48 import binding
                selected48=binding(mappings,sid)
                if selected48:
                    cid,source48,values48,used_provider=_read_binding(db,pid,channel,selected48,start,stop,limit,
                                                        strict=strict48,fallback=provider_fallback)
                    if used_provider:sender.provider_fallback.add(ident)
                    view.add(sid,ident,cid,values48)
                    tasks67.append((ident,cid,sid,source48,start,stop,limit))
                    continue
                alias=alias_rows89.get(ident)
                cid=alias[0] if alias else ident
                left=start  # Current/future before SQL LIMIT; no unsolicited history.
                right=start+21*86400 if history and sid==focus_sid else stop
                cap=256 if history and sid==focus_sid else min(256,limit)
                rows=db.execute('SELECT substr(title,1,512) AS title,substr(description,1,8192) AS description,start,stop,source FROM programmes WHERE pid=? AND cid=? AND stop>? AND start<? ORDER BY start,source,stop LIMIT ?',
                                (pid,cid,left,right,cap)).fetchall()
                view.add(sid,ident,cid,[dict(name=r['title'],descr=r['description'],start_timestamp=r['start'],
                                  stop_timestamp=r['stop'],source=r['source'],_source_index=r['source']) for r in rows])
                tasks67.append((ident,cid,sid,None,left,right,cap))
        # Commit all bounded core text before optional sidecar/schema work.
        from epg_resilience67 import optional
        from epg_merge52 import window as merged_window52
        from programme_flow48 import enrich
        for ident,cid,sid,source67,left,right,cap in tasks67:
            if time.monotonic()>deadline:break
            values67=for_channel(view,sid)[ident]
            if source67 is None:
                values67=optional(pid,sid,values67,lambda:merged_window52(pid,sid,cid,left,right,primary=values67,limit=cap,manual=bool(mappings.get(sid))))
            for_channel(view,sid)[ident][:]=optional(pid,sid,values67,lambda:enrich(pid,cid,values67[:4],source67,sid48=sid,revision48=view.revision)+values67[4:])
        return view
    except (OSError,sqlite3.Error) as error63:
        from epg_handoff63 import note
        first63=channels[0] if channels else {}
        sid63=channel_keys(first63,mappings)[0]
        note('DB_READ',pid,sid63,'EPG_DB_BUDGET' if getattr(error63,'sqlite_errorname','')=='SQLITE_INTERRUPT' else 'EPG_CACHE_UNAVAILABLE',(time.perf_counter()-started63)*1000)
        __import__('epg_read69').record(error63,pid,sid63,(time.perf_counter()-started63)*1000)
        return None
    finally:
        if db is not None:db.close()


@scoped
def _text_window65(pid,channels,mappings,start,stop,limit=48,focus_sid='',history=False,budget=.4,text_only65=False,provider_fallback=True):
    """Pin one RO guide; core text first, bounded optional metadata second."""
    import guide_store
    from programme_read47 import borrowed,retain
    filename=getattr(guide_store,'path',lambda:'')()
    if not filename or not os.path.isfile(filename):
        from programme_snapshot47 import fallback_window
        return fallback_window(pid,channels,mappings,start,stop,limit)
    db=None;started63=time.perf_counter();deadline=time.monotonic()+budget
    try:
        db=borrowed(filename)
        if db is None:
            raw=sqlite3.connect('file:'+quote(filename,safe='/')+'?mode=ro',uri=True,timeout=.05)
            raw.row_factory=sqlite3.Row;raw.execute('PRAGMA query_only=ON');db=retain(filename,raw)
        db.set_progress_handler(lambda:int(time.monotonic()>deadline),1000)
        meta=db.execute('SELECT * FROM guide_meta WHERE pid=?',(pid,)).fetchone()
        if not meta:
            from programme_snapshot47 import fallback_window
            return fallback_window(pid,channels,mappings,start,stop,limit)
        view=View();view.code='OK';record=dict(meta);view.revision=(record.get('revision'),record.get('updated'))
        alias_rows89=__import__('epg_single89').aliases(db,pid,channels,mappings)
        prepared={};tasks=[]
        # Core text first; an expensive sidecar cannot erase another sender.
        for channel in channels[:16]:
            sid,keys=channel_keys(channel,mappings)
            sender=view.channel(sid)
            for ident in keys:
                if ident in sender:continue
                from epg_binding48 import binding
                selected48=binding(mappings,sid)
                alias=None if selected48 else alias_rows89.get(ident)
                cid=selected48['channel'] if selected48 else alias[0] if alias else ident
                source48=selected48['source'] if selected48 else None
                left=start;right=start+21*86400 if history and sid==focus_sid else stop
                cap=256 if history and sid==focus_sid else min(256,limit)
                if selected48:
                    cid,source48,values,used_provider=_read_binding(db,pid,channel,selected48,left,right,cap,
                                                       fallback=provider_fallback)
                    if used_provider:sender.provider_fallback.add(ident)
                key=(str(sid),cid,source48,bool(mappings.get(sid)),right,cap)
                if key in prepared:view.add(sid,ident,cid,prepared[key]);continue
                if not selected48:
                    rows=db.execute('SELECT substr(title,1,512) AS title,substr(description,1,8192) AS description,start,stop,source FROM programmes WHERE pid=? AND cid=? AND stop>? AND start<? ORDER BY start,source,stop LIMIT ?',(pid,cid,left,right,cap)).fetchall()
                    values=[dict(name=row['title'],descr=row['description'],start_timestamp=row['start'],stop_timestamp=row['stop'],source=row['source'],_source_index=row['source']) for row in rows]
                prepared[key]=values;view.add(sid,ident,cid,values);tasks.append((key,cid,sid,source48,left,right,cap))
        # Source fusion is text work. Prefer gaps before optional rich fields.
        fusion65=sorted(tasks,key=lambda task:any(value['start_timestamp']<=start<value['stop_timestamp'] for value in prepared[task[0]]))
        for key,cid,sid,source48,left,right,cap in fusion65:
            if text_only65 and time.monotonic()>deadline:break
            if not source48:
                from epg_merge52 import window as merged_window52
                from epg_resilience67 import optional
                original67=prepared[key][:]
                prepared[key][:]=optional(pid,sid,original67,lambda:merged_window52(pid,sid,cid,left,right,primary=original67,limit=cap,manual=key[3]))
        for key,cid,sid,source48,left,right,cap in tasks:
            if time.monotonic()>deadline:break
            values=prepared[key]
            from programme_flow48 import enrich
            enriched=[]
            for index,value in enumerate(values):
                if index>=4 or text_only65 and time.monotonic()>deadline:
                    enriched.extend(values[index:]);break
                from epg_resilience67 import optional
                enriched.extend(optional(pid,sid,[value],lambda:enrich(pid,cid,[value],source48,sid48=sid,revision48=view.revision)))
            prepared[key][:]=enriched
        return view
    except (OSError,sqlite3.Error) as error63:
        from epg_handoff63 import note
        first63=channels[0] if channels else {};sid63=channel_keys(first63,mappings)[0]
        note('DB_READ',pid,sid63,'EPG_DB_BUDGET' if getattr(error63,'sqlite_errorname','')=='SQLITE_INTERRUPT' else 'EPG_CACHE_UNAVAILABLE',(time.perf_counter()-started63)*1000)
        __import__('epg_read69').record(error63,pid,sid63,(time.perf_counter()-started63)*1000)
        return None
    finally:
        if db is not None:db.close()


@scoped
def now_next(pid,channels,mappings,now=None,client=None,display_only65=False):
    from epg_single89 import run
    from epg_binding48 import view_mappings
    mappings = view_mappings(mappings)
    return run(pid,channels,mappings,now,display_only65,lambda:_now_next89(pid,channels,mappings,now,client,display_only65))


def _now_next89(pid,channels,mappings,now=None,client=None,display_only65=False):
    """Bounded local batch, including strictly cache-only short-EPG fallback."""
    from epg_views import resolve_guide
    ts=time.time() if now is None else now
    from epg_handoff63 import get as warm63,remember as remember63,note as note63,register as register63
    from epg_status import revision as revision63
    revision_before63=revision63(pid)
    if display_only65 and channels:
        prepared74={channel_keys(c,mappings)[0]:warm63(pid,channel_keys(c,mappings)[0],now=ts,mappings=mappings) for c in channels[:16]}
        if prepared74 and all(v and 0<=time.time()-v.get('_published_at63',0)<15 for v in prepared74.values()) and revision63(pid)==revision_before63:
            return prepared74
    from epg_poll77 import key as poll_key77,read as poll_read77,remember as poll_remember77
    cache_key77=poll_key77(pid,channels,mappings,display_only65)
    cached77=poll_read77(cache_key77,ts)
    if cached77 is not None:return cached77
    from epg_poll79 import select as select79,remember as remember79
    parked79,todo79=select79(pid,channels,mappings,ts,display_only65)
    if channels and not todo79:return parked79
    all_channels79=channels;channels=todo79
    from epg_poll79 import keys as keys79
    expected79=keys79(pid,channels,mappings,display_only65)
    started63=time.perf_counter()
    cache=window(pid,channels,mappings,ts,ts+2*86400,**({'text_only65':True} if display_only65 else {}))
    if cache is None:
        from epg_fallback67 import window as fallback67
        cache=fallback67(pid,channels,mappings,ts,ts+2*86400,48)
    if cache is not None:register63(pid,getattr(cache,'revision',None),expected_revision=revision_before63)
    db_ms63=(time.perf_counter()-started63)*1000
    # Workers retain the complete bounded future window. The thin four-event
    # RAM DTO is only a transient-read fallback and the GUI handoff, not a
    # replacement for catalogue/programme preparation.
    warm={channel_keys(c,mappings)[0]:warm63(pid,channel_keys(c,mappings)[0],now=ts,mappings=mappings) for c in channels[:16]}
    result={}
    for channel in channels[:16]:
        sid,keys=channel_keys(channel,mappings)
        extra=channel.extra if hasattr(channel,'extra') else channel
        provider=str(getattr(channel,'tvg_id','') or extra.get('epg_channel_id') or extra.get('tvg_id') or extra.get('xmltv_id') or '')
        compatibility47=cache is None or getattr(cache,'code','')=='SHARED_LASTGOOD47'
        info=resolve_guide(cache if cache is not None else {},provider,sid,ts,client if compatibility47 else None,mappings)
        info['snapshot_revision']=cache.revision if cache is not None else None
        info['canonical46']=getattr(for_channel(cache,sid),'canonical',{}).get(info.get('epg_id',''),info.get('epg_id','')) if cache is not None else ''
        from programme_snapshot47 import bind
        result[sid]=bind(pid,channel,info)
        if (not result[sid].get('now') and warm.get(sid) and warm[sid].get('now')
                and (cache is None or warm[sid].get('snapshot_revision')==info.get('snapshot_revision'))):
            result[sid]=warm[sid]
        if getattr(cache,'code','')!='RAM_LASTGOOD67':remember63(pid,channel,result[sid],mappings,expected_revision=revision_before63)
        code63=('READY' if info.get('now') else 'EPG_CACHE_UNAVAILABLE' if cache is None else 'EPG_MAPPING_MISSING' if info.get('reason')=='MANUAL_ID_MISSING' else 'EPG_DATA_MISSING')
        note63('DB_READ',pid,sid,code63,db_ms63,facts=info)
    if revision63(pid)==revision_before63:
        remember79(pid,channels,mappings,ts,display_only65,result,expected=expected79)
        result.update(parked79)
        if poll_key77(pid,all_channels79,mappings,display_only65)==cache_key77:poll_remember77(cache_key77,result,ts)
    return result


def next_start(pid,identifiers,now):
    """Search expiry at a real upcoming local event, not a fixed tab timer."""
    import guide_store
    filename=getattr(guide_store,'path',lambda:'')()
    ids=sorted(set(str(i) for i in identifiers if i))
    if not filename or not os.path.isfile(filename) or len(ids)>6000:return None
    db=None
    try:
        db=sqlite3.connect('file:'+quote(filename,safe='/')+'?mode=ro',uri=True,timeout=.05)
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        deadline=time.monotonic()+.2;db.set_progress_handler(lambda:int(time.monotonic()>deadline),1000)
        starts=[]
        for offset in range(0,len(ids),256):
            chunk=ids[offset:offset+256];marks=','.join('?' for _ in chunk)
            row=db.execute('SELECT min(start) FROM programmes WHERE pid=? AND cid IN ('+marks+') AND start>?',[pid]+chunk+[now]).fetchone()
            if row and row[0]:starts.append(row[0])
        return min(starts) if starts else None
    except (sqlite3.Error,OSError):return None
    finally:
        if db is not None:db.close()
