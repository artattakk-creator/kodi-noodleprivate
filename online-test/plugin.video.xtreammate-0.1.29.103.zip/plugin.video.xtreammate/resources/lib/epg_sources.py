from profile_transaction import serialized
"""Per-portal XMLTV source and channel mapping manager for Kodi/Android.

Built-in programme IDs take precedence; external feeds fill missing IDs.
Saved sender mappings take precedence for individual Xtream streams.
Configuration is separate from Kodi caches and survives add-on upgrades.
"""
import json
import os
import re
import tempfile
import uuid
from urllib.parse import urlsplit

from utils import addon_data_dir, cache_key, cache_get, cache_set, http_get, error

from epg_variant53 import channel_name_key as _channel_name_key
from epg_io import MAX_XML_BYTES, MAX_PROGRAMMES, XMLTVLimitError
from network_io import ResponseLimitError
INDEX_TTL = 30 * 86400

# Public third-party XMLTV links; availability and channel coverage can change.
# Presets are opt-in, never fetched merely because XCMate has been installed.
PRESET_FEEDS = (
    ('de_master', 'Deutschland · Kaimandura Master',
     'https://kaimandura.github.io/epg-de/DE-MASTER.xml.gz'),
    ('de_epgshare', 'Deutschland · EPGShare01',
     'https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz'),
    ('at_epgshare', 'Österreich · EPGShare01',
     'https://epgshare01.online/epgshare01/epg_ripper_AT1.xml.gz'),
    ('ch_epgshare', 'Schweiz · EPGShare01',
     'https://epgshare01.online/epgshare01/epg_ripper_CH1.xml.gz'),
    ('nl_epgshare', 'Niederlande · EPGShare01 (optional)',
     'https://epgshare01.online/epgshare01/epg_ripper_NL1.xml.gz'),
)


@serialized
def add_presets(portal_id, preset_keys):
    """Install selected XMLTV feeds idempotently, without touching existing ones."""
    wanted = set(preset_keys)
    known = {key for key, _, _ in PRESET_FEEDS}
    if wanted - known:
        raise ValueError('Unbekanntes EPG-Paket')
    state = configuration(portal_id)
    existing = {str(item.get('uri', '')) for item in state['sources']}
    added = []
    for key, title, uri in PRESET_FEEDS:
        if key not in wanted or uri in existing:
            continue
        state['sources'].append({
            'id': uuid.uuid4().hex, 'name': title, 'uri': uri,
            'local': False, 'enabled': True,
        })
        existing.add(uri)
        added.append(key)
    if added:
        _save(portal_id, state)
    if any(s.get('enabled',True) for s in state['sources']):__import__('epg_config94').source_added(portal_id)
    return added


def _file_path():
    return os.path.join(addon_data_dir(), 'xtreammate_epg_sources.json')


def _load_all():
    path = _file_path()
    if not os.path.isfile(path):
        return {}
    with open(path, 'r', encoding='utf-8') as stream:
        data = json.load(stream)
    if not isinstance(data, dict):
        raise ValueError('Ungültige EPG-Konfiguration')
    return data


def _write_all(data):
    folder = os.path.dirname(_file_path())
    os.makedirs(folder, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.xtreammate-epg-', dir=folder)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, _file_path())
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def configuration(portal_id):
    entry = _load_all().get(str(portal_id), {})
    if not isinstance(entry, dict):
        raise ValueError('Ungültige Portal-EPG-Konfiguration')
    from epg_binding48 import Mappings
    result = {
        'sources': [dict(s) for s in entry.get('sources', []) if isinstance(s, dict)],
        'mappings': Mappings(entry.get('mappings', {}),entry.get('source_mappings48',{})),
    }
    if entry.get('source_mappings48'):result['source_mappings48']=dict(entry['source_mappings48'])
    return result


@serialized
def _save(portal_id, state):
    all_data = _load_all()
    pid = str(portal_id)
    all_data[pid] = dict(all_data.get(pid, {}), **state)
    _write_all(all_data)
    from epg_status import changed
    changed(portal_id)


@serialized
def add_source(portal_id, title, uri, local=False):
    uri = str(uri).strip()
    if not uri:
        raise ValueError('Die EPG-Adresse fehlt')
    if local:
        if '://' in uri and not uri.startswith(('special://', 'smb://', 'nfs://',
                                                 'content://', 'file://')):
            raise ValueError('Nicht unterstützter Dateipfad')
    else:
        parsed = urlsplit(uri)
        if parsed.scheme.lower() not in ('http', 'https') or not parsed.netloc:
            raise ValueError('Bitte eine gültige HTTP- oder HTTPS-Adresse eingeben')
    state = configuration(portal_id)
    if any(s.get('uri') == uri for s in state['sources']):
        raise ValueError('Diese Quelle wurde bereits hinzugefügt')
    item = {'id': uuid.uuid4().hex, 'name': str(title).strip() or 'XMLTV',
            'uri': uri, 'local': bool(local), 'enabled': True}
    state['sources'].append(item)
    _save(portal_id, state)
    __import__('epg_config94').source_added(portal_id)
    return item


@serialized
def edit_source(portal_id, source_id, operation):
    state = configuration(portal_id)
    index = next((i for i, s in enumerate(state['sources'])
                  if s.get('id') == source_id), -1)
    if index < 0:
        return False
    if operation == 'toggle':
        s = state['sources'][index]
        s['enabled'] = not s.get('enabled', True)
    elif operation == 'delete':
        del state['sources'][index]
    elif operation in ('up', 'down'):
        dest = index + (-1 if operation == 'up' else 1)
        if dest < 0 or dest >= len(state['sources']):
            return False
        state['sources'][index], state['sources'][dest] = (
            state['sources'][dest], state['sources'][index])
    else:
        raise ValueError('Ungültige EPG-Aktion')
    _save(portal_id, state)
    if operation=='toggle' and state['sources'][index].get('enabled',True):__import__('epg_config94').source_added(portal_id)
    return True


@serialized
def set_mapping(portal_id, stream_id, epg_id):
    state = configuration(portal_id)
    sid = str(stream_id).strip()
    eid = str(epg_id).strip()
    if not sid:
        raise ValueError('Sender-ID fehlt')
    state.get('source_mappings48',{}).pop(sid,None)
    if eid:
        state['mappings'][sid] = eid
    else:
        state['mappings'].pop(sid, None)
    _save(portal_id, state)


def _read_source(source):
    uri = str(source.get('uri') or '')
    if source.get('local'):
        import xbmcvfs
        f = xbmcvfs.File(uri)
        try:
            raw = f.readBytes(MAX_XML_BYTES + 1)
        finally:
            f.close()
    else:
        if urlsplit(uri).scheme.lower() not in ('http', 'https'):
            raise ValueError('Nur HTTP(S)-EPG-Adressen sind erlaubt')
        raw, _ = http_get(uri, timeout=20, max_bytes=MAX_XML_BYTES, max_seconds=60)
    raw = bytes(raw) if not isinstance(raw, bytes) else raw
    if len(raw) > MAX_XML_BYTES:
        raise XMLTVLimitError('XMLTV-Datei ist zu groß (max. 80 MB)', 'input_bytes')
    # GZIP is expanded incrementally by parse_xmltv, under the same size budget
    # as the provider guide. Never allocate the whole uncompressed feed here.
    if b'<!DOCTYPE' in raw[:4096].upper() or b'<!ENTITY' in raw[:4096].upper():
        raise ValueError('XML-Dokument mit DTD/Entities nicht erlaubt')
    return raw


def _channels_cache_key(portal_id):
    return cache_key('xtreammate_epg_channel_index_' + str(portal_id))


def available_channels(portal_id):
    result = cache_get(_channels_cache_key(portal_id), max_age=INDEX_TTL)
    return result if isinstance(result, dict) else {}


def _link_cached_xtream_channels(portal_id, programmes, channel_index):
    """Map unambiguous channel names only; preserve provider and manual IDs.

    This runs during EPG refresh, never on the remote control/UI thread.
    Ambiguous station names from several countries require manual mapping.
    """
    try:
        import portals
        from xtream import XtreamClient
        portal = portals.get_by_id(portal_id)
        if not portal or portal.get('type') != 'xtream':
            return 0
        client = XtreamClient(portal['xc_host'], portal['xc_user'], portal['xc_pass'])
        streams = client.get_cached_catalog('get_live_streams') or []
    except Exception as exc:
        error('EPG auto-link unavailable: {}'.format(type(exc).__name__))
        return 0
    names = {}
    for channel_id, display_name in channel_index.items():
        if not programmes.get(channel_id):
            continue
        key = _channel_name_key(display_name)
        if not key:
            continue
        if key in names and names[key] != channel_id:
            names[key] = None  # ambiguous: refuse to guess
        elif key not in names:
            names[key] = channel_id
    count = 0
    for channel in streams:
        if not isinstance(channel, dict):
            continue
        stream_id = str(channel.get('stream_id') or '').strip()
        provider_id = str(channel.get('epg_channel_id') or '').strip()
        if not stream_id or programmes.get(stream_id) or (
                provider_id and programmes.get(provider_id)):
            continue
        source_id = names.get(_channel_name_key(channel.get('name')))
        if source_id and source_id in programmes:
            programmes[stream_id] = programmes[source_id]
            count += 1
    return count


def merge_sources(portal_id, builtin_programmes, parse_xmltv):
    """Fetch enabled XMLTV feeds; retain built-in data when any feed fails.

    Provider IDs win, followed by the first enabled external feed. Explicit
    sender-to-XMLTV mapping is applied last and wins.
    """
    state = configuration(portal_id)
    merged = dict(builtin_programmes or {})
    index = {}
    successes, failures = 0, 0
    programme_count = sum(len(entries) for entries in merged.values())
    for source_index, source in enumerate(state['sources'], 1):
        if not source.get('enabled', True):
            continue
        raw, stage = None, 'DOWNLOAD'
        from epg_status import update as source_status, source_key
        key = source_key(source)
        source_status(portal_id, key, 'RUNNING', running=True, source_index=source_index)
        try:
            raw = _read_source(source)
            from live_diagnostics import record
            record('epg_source','READ',bytes=len(raw),source_index=source_index)
            source_status(portal_id, key, 'READ', running=True, source_index=source_index,bytes=len(raw))
            stage = 'PARSE'
            channels, programmes = parse_xmltv(raw)
            if not programmes:
                from epg_errors import EmptyGuideError
                raise EmptyGuideError('XMLTV enthält keine gültigen Sendungen')
            stage = 'MERGE'
            from epg_merge44 import extend
            for channel_id,entries in programmes.items():
                combined,added_count=extend(merged.get(channel_id,[]),entries,source_index)
                if programme_count+added_count>MAX_PROGRAMMES:
                    raise XMLTVLimitError('Combined XMLTV programme limit exceeded','programmes')
                programme_count+=added_count
                if combined:merged[channel_id]=combined
            index.update(channels)
            successes += 1
            record('epg_source','READY',channels=len(channels),
                   programmes=sum(len(v) for v in programmes.values()),loaded=successes,
                   failed=failures,bytes=len(raw),source_index=source_index)
            source_status(portal_id, key, 'READY', running=False, source_index=source_index,
                          channels=len(channels), programmes=sum(len(v) for v in programmes.values()),
                          bytes=len(raw))
        except Exception as exc:
            from live_diagnostics import record
            from epg_errors import failure_details
            code, fields = failure_details(exc, stage)
            record('epg_source',code,source_index=source_index,
                   failed=failures+1,bytes=len(raw) if raw is not None else 0, **fields)
            source_status(portal_id, key, code, running=False, source_index=source_index,
                          bytes=len(raw) if raw is not None else 0, **fields)
            failures += 1
            error('EPG source failed ({}): {}'.format(
                source.get('id', '')[:8], type(exc).__name__))
        finally:
            raw=None  # No raw feed survives into the next source/download.
    if index:
        cache_set(_channels_cache_key(portal_id), index)
        linked = _link_cached_xtream_channels(portal_id, merged, index)
    for stream_id, xmltv_id in state['mappings'].items():
        if xmltv_id in merged:
            merged[str(stream_id)] = merged[xmltv_id]
    return merged, successes, failures


def _choose_portal():
    import portals
    import xbmcgui
    active = portals.get_active()
    if not active:
        xbmcgui.Dialog().ok('XCMate EPG', 'Bitte zuerst einen TV-Zugang einrichten.')
        return None
    if len(active) == 1:
        return active[0]
    i = __import__('menu_icons45').select(xbmcgui.Dialog(),'EPG: TV-Liste wählen', [p['name'] for p in active],default='database')
    return active[i] if 0 <= i < len(active) else None


def _choose_preset(portal):
    """Native Kodi picker, deliberately avoiding multiple automatic downloads."""
    import xbmcgui
    from epg import warmup_async
    dialog = xbmcgui.Dialog()
    existing = {s.get('uri') for s in configuration(portal['id'])['sources']}
    labels = [('✓ ' if uri in existing else '＋ ') + title
              for _, title, uri in PRESET_FEEDS]
    labels.append('＋ DACH-Paket: Deutschland (2), Österreich, Schweiz')
    selection = __import__('menu_icons45').select(dialog,'XCMate – EPG-Pakete auswählen', labels,default='database')
    if selection < 0:
        return False
    keys = ([PRESET_FEEDS[selection][0]] if selection < len(PRESET_FEEDS)
            else ['de_master', 'de_epgshare', 'at_epgshare', 'ch_epgshare'])
    if not __import__('epg_config94').confirm_enable(portal):return False
    added = add_presets(portal['id'], keys)
    if not added:
        dialog.notification('XCMate EPG', 'EPG-Paket bereits vorhanden')
        return False
    dialog.notification('XCMate EPG',
                        '{} Quelle(n) gespeichert. EPG bei Bedarf manuell laden.'.format(len(added)))
    # Avoid automatically parsing several large XMLTV files on Android TV.
    return True


def _manage_source(portal, source):
    import xbmcgui
    d = xbmcgui.Dialog()
    choice = __import__('menu_icons45').select(d,str(source.get('name') or 'XMLTV'), [
        'Quelle ' + ('deaktivieren' if source.get('enabled', True) else 'aktivieren'),
        'Priorität erhöhen', 'Priorität senken',
        'Quelle löschen', 'Zurück'],default='database')
    operations = ('toggle', 'up', 'down', 'delete')
    if choice < 0 or choice >= len(operations):
        return False
    if choice == 3 and not d.yesno('XCMate EPG', 'EPG-Quelle wirklich löschen?'):
        return False
    if choice==0 and not source.get('enabled',True) and not __import__('epg_config94').confirm_enable(portal):return False
    return edit_source(portal['id'], source['id'], operations[choice])


def _choose_mapping(portal):
    import xbmcgui
    d = xbmcgui.Dialog()
    if portal.get('type') != 'xtream':
        d.ok('XCMate EPG', 'Manuelle Zuordnung wird derzeit für Xtream Codes unterstützt.')
        return
    from xtream import XtreamClient
    xc = XtreamClient(portal['xc_host'], portal['xc_user'], portal['xc_pass'])
    streams = xc.get_cached_catalog('get_live_streams') or []
    streams = sorted((x for x in streams if isinstance(x, dict) and x.get('stream_id')),
                     key=lambda x: str(x.get('name') or '').casefold())
    index = available_channels(portal['id'])
    if not streams:
        d.ok('XCMate EPG', 'Senderkatalog wird noch geladen. Bitte später erneut versuchen.')
        return
    if not index:
        d.ok('XCMate EPG', 'Zuerst eine XMLTV-Quelle hinzufügen und EPG aktualisieren.')
        return
    state = configuration(portal['id'])
    labels = []
    for s in streams:
        sid = str(s['stream_id'])
        eid = state['mappings'].get(sid, '')
        labels.append(str(s.get('name') or sid) + (('  →  ' + eid) if eid else ''))
    i = __import__('menu_icons45').select(d,'Xtream-Sender zuordnen', labels,default='database')
    if i < 0:
        return
    sid = str(streams[i]['stream_id'])
    channels = sorted(index.items(), key=lambda x: str(x[1]).casefold())
    options = ['Zuordnung entfernen'] + [
        '{}  [{}]'.format(name, cid) for cid, name in channels]
    selected = state['mappings'].get(sid, '')
    preselect = next((j + 1 for j, (cid, _) in enumerate(channels)
                      if cid == selected), 0)
    j = __import__('menu_icons45').select(d,'XMLTV-Kanal wählen', options, preselect=preselect,default='database')
    if j >= 0:
        set_mapping(portal['id'], sid, channels[j - 1][0] if j else '')
        d.notification('XCMate EPG', 'Zuordnung gespeichert – EPG bitte aktualisieren')


def manage(portal=None):
    """One central manager; retain existing source editing and binding services."""
    portal=portal or _choose_portal()
    if not portal:return
    from epg_manager53 import manage as open_manager
    return open_manager(portal)
