"""Bounded read-only EPG viewport; no imports, HTTP or provider mutations."""
import time

ROWS=8
SPAN=3*3600
CELLS=24


def rectangle(start,stop,origin,span=SPAN,width=896):
    left=max(start,origin);right=min(stop,origin+span)
    if right<=left:return None
    x=int((left-origin)*width/span);end=int((right-origin)*width/span)
    return x,max(1,end-x)


def page(portal,offset,origin,category=None,client=None,mappings48=None,strict48=False):
    from library_index import Reader
    from epg_sources import configuration
    from epg_events import deduplicate
    reader=Reader(portal['id']);channels,total=reader.page('live',category=category,offset=offset,limit=ROWS)
    from epg_binding48 import view_mappings
    mappings=view_mappings(configuration(portal['id']).get('mappings',{}) if mappings48 is None else mappings48)
    result=[]
    from local_epg import window,channel_keys,for_channel
    snapshot=window(portal['id'],channels,mappings,origin,origin+SPAN,limit=101,
                    strict48=strict48,provider_fallback=mappings48 is None)
    if snapshot is None and not strict48:
        from epg_fallback67 import window as fallback67
        snapshot=fallback67(portal['id'],channels,mappings,origin,origin+SPAN,101)
    state='OK' if snapshot is not None else 'NOT_CREATED'
    for channel in channels:
        sid,ids=channel_keys(channel,mappings);manual=mappings.get(sid)
        events=[];resolved=str(manual or '');mapping='MANUAL' if manual else 'UNMAPPED'
        if snapshot is not None:
            from epg_binding48 import qualified_cache
            sender=for_channel(snapshot,sid)
            selected=qualified_cache(sender,mappings,sid)
            for ident in ids:
                raw=selected.get(ident,[])
                if raw:
                    resolved=getattr(sender,'canonical',{}).get(ident,ident)
                    events=deduplicate(raw[:100],channel=resolved)
                    if ident in getattr(sender,'provider_fallback',()):mapping='MANUAL_PROVIDER_FALLBACK'
                    elif not manual:mapping='STREAM_ALIAS' if ident==sid else 'PROVIDER_ID'
                    break
        if not events and not manual and client is not None and origin<=time.time()<origin+SPAN:
            from epg_views import cached_short_guide
            short=cached_short_guide(client,sid)
            events=[dict(e,source=-1) for e in short.get('events',[]) if e['start']<origin+SPAN and e['stop']>origin]
            if events:mapping='SHORT_EPG'
        from programme_snapshot47 import identify
        events=identify(portal['id'],sid,resolved,events)
        if mappings48 is not None:events=[dict(event,_no_art_request68=True) for event in events]
        result.append(dict(channel=channel,events=events,mapping=mapping,epg_id=resolved,
                           truncated=len(events)>CELLS))
    # Original persistent artwork cache, queued from this viewport worker.
    # No remote texture ever reaches the GUI and no cache path is changed.
    from media_art import request
    if mappings48 is None:
        request(channels)
        from programme_events46 import describe
        from programme_requests68 import request as request_event68
        revision68=getattr(snapshot,'revision',None)
        for item68 in result[:ROWS]:
            for event68 in item68['events']:event68['revision68']=revision68
            # One currently visible/first future event per row; a focused
            # different event uses the same broker through Preview's worker.
            raw68=next((v for v in item68['events'] if v['start']<=time.time()<v['stop']),
                       next((v for v in item68['events'] if v['stop']>origin),None))
            if raw68:
                value68=describe(portal,item68['channel'],raw68,item68['epg_id'],revision68)
                request_event68(value68,priority=True)
    from guide_publish44 import history_days
    from guide_store import path
    history=history_days(portal['id'],path()) if origin<__import__('guide_store').day_window(0)[0] else None
    return dict(rows=result,total=total,groups=reader.groups('live'),code=state,origin=origin,offset=offset,revision=getattr(snapshot,'revision',None),history44=history)


def initial(portal,origin,client=None,selected_sid80='',selected_group80=''):
    """Select one enabled start group and reveal the unmodified channel order."""
    from library_index import Reader
    reader=Reader(portal['id']);groups=reader.groups('live')
    allowed={str(g['cid']) for g in groups}
    start=reader.get('live',str(selected_sid80 or portal.get('start_stream_id') or ''))
    saved=str(selected_group80 or portal.get('start_group_id') or '')
    category=saved if saved in allowed else ''
    if selected_sid80 and start and reader.position('live',start['sid'],category) is None:category=str(start.get('category_id') or '')
    position=reader.position('live',start['sid'],category) if start and category else None
    if start and not category:
        candidate=str(start.get('category_id') or '')
        if candidate in allowed:category=candidate
    if not category:category=str(groups[0]['cid']) if groups else ''
    position=reader.position('live',start['sid'],category) if start and category else None
    start_in_group=position is not None
    position=position if position is not None else 0
    offset=position//ROWS*ROWS
    # Empty category is deliberately an empty selection, never category=None.
    value=page(portal,offset,origin,category,client)
    catalogue=reader.state('live') if not groups else None
    # A blank revision can be the placeholder left when Live was disabled.
    # Once enabled, wait for the first real catalogue before resolving saved focus.
    catalog_known=bool(groups or (catalogue and (catalogue['revision'] or not portal.get('include_live',True))))
    value.update(category=category,row=position-offset,catalog_known=catalog_known)
    try:
        import xbmc
        xbmc.log('[XCMate][GUIDE_GROUP] stage=INITIAL groups={} saved_active={} selected_saved={} start_found={} start_in_group={} rows={} category_empty={} category_star={}'.format(
            len(groups),int(saved in allowed),int(bool(saved) and category==saved),int(start is not None),
            int(start_in_group),len(value['rows']),int(category==''),int(category=='*')),xbmc.LOGINFO)
    except (ImportError,AttributeError,RuntimeError):pass
    return value
