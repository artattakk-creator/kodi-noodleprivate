"""Per-portal startup group/channel selection using stable Xtream category IDs."""
import xbmcgui
from portals import get_by_id, update, PortalReadError
from xtream import XtreamClient
from group_selection import enabled_ids


def candidates(groups, streams, enabled):
    names={str(g.get('category_id')):str(g.get('category_name','')) for g in groups}
    allowed={str(x) for x in enabled}
    channels=[c for c in streams if str(c.get('category_id','')) in allowed and c.get('stream_id')]
    return names,channels


def configure_startup(portal):
    if portal.get('type') not in ('xtream','m3u','stb'):
        return False
    dlg=xbmcgui.Dialog()
    if portal.get('type')=='xtream':
        xc=XtreamClient(portal['xc_host'],portal['xc_user'],portal['xc_pass'])
        categories=xc.get_live_categories()
    else:
        from source_adapters import for_portal
        xc=for_portal(portal);categories=xc.get_cached_catalog('get_live_categories')
    groups=[c for c in categories if isinstance(c,dict)]
    if not groups:
        dlg.ok('XCMate','Keine Sendergruppen vom Portal verfügbar.')
        return False
    selected=enabled_ids(portal['id'],'live',groups)
    visible=[g for g in groups if str(g.get('category_id')) in selected]
    if not visible:
        dlg.ok('XCMate','Bitte zuerst mindestens eine Sendergruppe aktivieren.')
        return False
    prev=str(portal.get('start_group_id') or '*')
    options=['Alle aktivierten Gruppen']+[str(g.get('category_name',g.get('category_id'))) for g in visible]
    initial=1+next((i for i,g in enumerate(visible) if str(g.get('category_id'))==prev),-1)
    position=__import__('menu_icons45').select(dlg,'XCMate – Start-Sendergruppe', options, preselect=max(0,initial),default='tv')
    if position<0: return False
    group='*' if position==0 else str(visible[position-1]['category_id'])
    streams=[x for x in (xc.get_live_streams() if portal.get('type')=='xtream' else xc.get_cached_catalog('get_live_streams')) if isinstance(x,dict) and x.get('stream_id')]
    names,available=candidates(groups,streams,selected)
    if group!='*':
        available=[x for x in available if str(x.get('category_id'))==group]
    if not available:
        dlg.ok('XCMate','In dieser Sendergruppe sind keine aktiven Sender verfügbar.')
        return False
    old_sid=str(portal.get('start_stream_id') or '')
    initial=next((i for i,ch in enumerate(available) if str(ch['stream_id'])==old_sid),0)
    chosen=__import__('menu_icons45').select(dlg,'XCMate – Startsender',
        [str(c.get('name','Sender')) for c in available],preselect=initial,default='tv')
    if chosen<0: return False
    channel=available[chosen]
    autoplay=portal.get('type')=='xtream' and dlg.yesno('XCMate – Automatischer Start',
        'Soll dieser Sender automatisch starten, wenn XCMate geöffnet wird? '
        'Mit Nein bleibt der Sender über „Startsender abspielen“ erreichbar.')
    changes = dict(start_group_id=group, start_stream_id=str(channel['stream_id']),
                   autoplay_start=autoplay)
    try:
        from profile_transaction import writing
        with writing():
            saved = get_by_id(portal['id'])
            if not saved or (any(saved.get(k) != v for k, v in changes.items())
                             and not update(portal['id'], changes)):
                raise OSError('START_PREFERENCES_WRITE_FAILED')
            saved = get_by_id(portal['id'])
            if not saved or any(saved.get(k) != v for k, v in changes.items()):
                raise OSError('START_PREFERENCES_READBACK_FAILED')
    except (OSError, PortalReadError):
        dlg.ok('XCMate','Die Startauswahl konnte nicht bestätigt werden. Bitte erneut versuchen.')
        return False
    dlg.notification('XCMate','Startgruppe und Startsender gespeichert')
    return True
