# Original BINGIE dependency bootstrap; intentionally inert.
